<?php
// ============================================================
//  CotizaApp — modules/auth/registro_post.php
//  POST /registro — Procesa la creación de nueva empresa
// ============================================================

defined('COTIZAAPP') or die;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/registro');
}

// CSRF
csrf_check();

// Solo en dominio raíz
if (EMPRESA_ID > 0) {
    redirect('/');
}

// ─── Recoger y limpiar valores ───────────────────────────
$nombre_empresa = trim($_POST['nombre_empresa'] ?? '');
$slug_raw       = trim(strtolower($_POST['slug'] ?? ''));
$nombre         = trim($_POST['nombre'] ?? '');
$usuario_str    = trim(strtolower($_POST['usuario'] ?? ''));
$password       = $_POST['password'] ?? '';
$moneda         = $_POST['moneda'] ?? 'MXN';
$impuesto_modo  = $_POST['impuesto_modo'] ?? 'ninguno';
$impuesto_pct   = (float)($_POST['impuesto_pct'] ?? 16);

// ─── Validaciones ────────────────────────────────────────
$errores = [];
$valores = compact(
    'nombre_empresa','slug_raw','nombre',
    'usuario_str','moneda','impuesto_modo','impuesto_pct'
);
$valores['slug'] = $slug_raw; // Para repoblar el campo

// Empresa
if (empty($nombre_empresa) || strlen($nombre_empresa) < 2) {
    $errores['nombre_empresa'] = 'Nombre de empresa requerido (mínimo 2 caracteres)';
}

// Slug
if (empty($slug_raw)) {
    $errores['slug'] = 'El subdominio es requerido';
} elseif (!preg_match('/^[a-z0-9][a-z0-9\-]{1,58}[a-z0-9]$/', $slug_raw)) {
    $errores['slug'] = 'Solo letras minúsculas, números y guiones. Mínimo 3 caracteres.';
} else {
    // Verificar disponibilidad
    $existe = DB::val("SELECT id FROM empresas WHERE slug = ?", [$slug_raw]);
    if ($existe) {
        $errores['slug'] = "El subdominio «{$slug_raw}» ya está en uso. Elige otro.";
    }
}

// Usuario
if (empty($nombre) || strlen($nombre) < 2) {
    $errores['nombre'] = 'Tu nombre es requerido';
}
if (empty($usuario_str) || strlen($usuario_str) < 3) {
    $errores['usuario'] = 'El usuario debe tener al menos 3 caracteres';
} elseif (!preg_match('/^[a-z0-9][a-z0-9\.\-\_]{1,58}[a-z0-9]$/i', $usuario_str)) {
    $errores['usuario'] = 'Solo letras, números, puntos y guiones';
}
if (strlen($password) < 6) {
    $errores['password'] = 'La contraseña debe tener al menos 6 caracteres';
}

// Moneda e impuesto
$monedas_validas        = ['MXN','USD','EUR'];
$impuesto_modos_validos = ['ninguno','suma','incluido'];

if (!in_array($moneda, $monedas_validas))              $moneda = 'MXN';
if (!in_array($impuesto_modo, $impuesto_modos_validos)) $impuesto_modo = 'ninguno';
if ($impuesto_pct < 0 || $impuesto_pct > 100)          $impuesto_pct = 16.00;

// ─── Si hay errores, devolver al registro ────────────────
if (!empty($errores)) {
    $_SESSION['registro_errores'] = $errores;
    $_SESSION['registro_valores'] = $valores;
    redirect('/registro');
}

// ─── Crear empresa y admin ───────────────────────────────
try {
    DB::beginTransaction();

    // Crear empresa
    $empresa_id = DB::insert(
        "INSERT INTO empresas
         (slug, nombre, moneda, impuesto_modo, impuesto_pct, activa)
         VALUES (?, ?, ?, ?, ?, 1)",
        [$slug_raw, $nombre_empresa, $moneda, $impuesto_modo, $impuesto_pct]
    );

    // Folios iniciales
    $anio = (int) date('Y');
    foreach (['COT', 'VTA', 'REC'] as $tipo) {
        DB::execute(
            "INSERT IGNORE INTO folios (empresa_id, tipo, anio, ultimo) VALUES (?, ?, ?, 0)",
            [$empresa_id, $tipo, $anio]
        );
    }

    // Categorías de costos por defecto
    $cats = [
        ['Material extra',      '#3b82f6'],
        ['Mano de obra',        '#10b981'],
        ['Transporte',          '#8b5cf6'],
        ['Instalación',         '#f59e0b'],
        ['Garantía / servicio', '#06b6d4'],
    ];
    foreach ($cats as [$cat_nombre, $cat_color]) {
        DB::execute(
            "INSERT INTO categorias_costos (empresa_id, nombre, color, activa) VALUES (?, ?, ?, 1)",
            [$empresa_id, $cat_nombre, $cat_color]
        );
    }

    // Crear usuario admin
    DB::insert(
        "INSERT INTO usuarios
         (empresa_id, nombre, usuario, password_hash, rol,
          puede_editar_precios, puede_aplicar_descuentos, puede_ver_todas_cots,
          puede_ver_todas_ventas, puede_eliminar_items_venta, puede_cancelar_recibos)
         VALUES (?, ?, ?, ?, 'admin', 1, 1, 1, 1, 1, 1)",
        [
            $empresa_id,
            $nombre,
            $usuario_str,
            password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
        ]
    );

    DB::commit();

} catch (Exception $e) {
    DB::rollback();

    if (DEBUG) throw $e;

    $_SESSION['registro_errores'] = ['general' => 'Error al crear la cuenta. Intenta de nuevo.'];
    $_SESSION['registro_valores'] = $valores;
    redirect('/registro');
}

// ─── Redirigir al subdominio nuevo ───────────────────────
// El usuario llega a empresa.cotiza.cloud/login con flag de cuenta nueva
$url_login = 'https://' . $slug_raw . '.' . BASE_DOMAIN . '/login?nuevo=1&u=' . urlencode($usuario_str);
redirect($url_login);
