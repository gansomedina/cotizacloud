<?php
// ============================================================
//  cotiza.cloud — modules/config/usuario.php
//  POST /config/usuario         → crear
//  POST /config/usuario/:id     → editar
// ============================================================
defined('COTIZAAPP') or die;
Auth::requerir_admin();
header('Content-Type: application/json');

$eid    = EMPRESA_ID;
$usr_id = isset($id) ? (int)$id : 0;

$body = json_decode(file_get_contents('php://input'), true);
if (!$body) { echo json_encode(['ok'=>false,'error'=>'Payload inválido']); exit; }

$nombre  = mb_substr(trim($body['nombre']  ?? ''), 0, 120);
$usuario = mb_substr(strtolower(trim($body['usuario'] ?? '')), 0, 60);
$email   = mb_substr(trim($body['email']   ?? ''), 0, 120) ?: null;
$rol     = in_array($body['rol']??'', ['admin','asesor']) ? $body['rol'] : 'asesor';
$activo  = (int)($body['activo'] ?? 1);
$pass    = $body['password'] ?? '';

// Validaciones
if ($nombre === '')  { echo json_encode(['ok'=>false,'error'=>'El nombre es obligatorio']); exit; }
if ($usuario === '') { echo json_encode(['ok'=>false,'error'=>'El usuario es obligatorio']); exit; }
if (!preg_match('/^[a-z0-9._\-]{1,60}$/', $usuario)) {
    echo json_encode(['ok'=>false,'error'=>'Usuario inválido — solo minúsculas, números y . _ -']); exit;
}

// Permisos granulares (solo aplican a asesores)
$perms = [
    'puede_editar_precios'       => (int)($body['puede_editar_precios']       ?? 1),
    'puede_aplicar_descuentos'   => (int)($body['puede_aplicar_descuentos']   ?? 1),
    'puede_ver_todas_cots'       => (int)($body['puede_ver_todas_cots']       ?? 0),
    'puede_ver_todas_ventas'     => (int)($body['puede_ver_todas_ventas']     ?? 0),
    'puede_eliminar_items_venta' => (int)($body['puede_eliminar_items_venta'] ?? 0),
    'puede_cancelar_recibos'     => (int)($body['puede_cancelar_recibos']     ?? 0),
];
if ($rol === 'admin') {
    // Admin tiene todos los permisos implícitos
    $perms = array_map(fn() => 1, $perms);
}

if ($usr_id > 0) {
    // ── EDITAR ───────────────────────────────────────────────
    $u = DB::row("SELECT id, usuario FROM usuarios WHERE id=? AND empresa_id=?", [$usr_id, $eid]);
    if (!$u) { echo json_encode(['ok'=>false,'error'=>'Usuario no encontrado']); exit; }

    // Verificar nombre de usuario único (excepto el mismo)
    $dup = DB::val("SELECT id FROM usuarios WHERE empresa_id=? AND usuario=? AND id!=?", [$eid, $usuario, $usr_id]);
    if ($dup) { echo json_encode(['ok'=>false,'error'=>'Ese nombre de usuario ya está en uso']); exit; }

    // No permitir desactivar al único admin
    if ($activo === 0) {
        $admin_count = DB::val("SELECT COUNT(*) FROM usuarios WHERE empresa_id=? AND rol='admin' AND activo=1 AND id!=?", [$eid, $usr_id]);
        $esta_admin  = DB::val("SELECT rol FROM usuarios WHERE id=?", [$usr_id]) === 'admin';
        if ($esta_admin && (int)$admin_count === 0) {
            echo json_encode(['ok'=>false,'error'=>'No puedes desactivar al único admin']); exit;
        }
    }

    $set = "nombre=?, usuario=?, email=?, rol=?, activo=?,
            puede_editar_precios=?, puede_aplicar_descuentos=?,
            puede_ver_todas_cots=?, puede_ver_todas_ventas=?,
            puede_eliminar_items_venta=?, puede_cancelar_recibos=?";
    $vals = [
        $nombre, $usuario, $email, $rol, $activo,
        $perms['puede_editar_precios'], $perms['puede_aplicar_descuentos'],
        $perms['puede_ver_todas_cots'], $perms['puede_ver_todas_ventas'],
        $perms['puede_eliminar_items_venta'], $perms['puede_cancelar_recibos'],
    ];

    if ($pass !== '') {
        if (strlen($pass) < 8) { echo json_encode(['ok'=>false,'error'=>'La contraseña debe tener al menos 8 caracteres']); exit; }
        $set .= ', password_hash=?';
        $vals[] = password_hash($pass, PASSWORD_DEFAULT);
    }

    $vals[] = $usr_id;
    DB::execute("UPDATE usuarios SET $set WHERE id=?", $vals);
    echo json_encode(['ok'=>true, 'id'=>$usr_id]);

} else {
    // ── CREAR ────────────────────────────────────────────────
    if (strlen($pass) < 8) { echo json_encode(['ok'=>false,'error'=>'La contraseña debe tener al menos 8 caracteres']); exit; }

    $dup = DB::val("SELECT id FROM usuarios WHERE empresa_id=? AND usuario=?", [$eid, $usuario]);
    if ($dup) { echo json_encode(['ok'=>false,'error'=>'Ese nombre de usuario ya está en uso']); exit; }

    $nuevo = DB::insert(
        "INSERT INTO usuarios
         (empresa_id, nombre, usuario, email, password_hash, rol, activo,
          puede_editar_precios, puede_aplicar_descuentos,
          puede_ver_todas_cots, puede_ver_todas_ventas,
          puede_eliminar_items_venta, puede_cancelar_recibos)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [
            $eid, $nombre, $usuario, $email,
            password_hash($pass, PASSWORD_DEFAULT),
            $rol, $activo,
            $perms['puede_editar_precios'], $perms['puede_aplicar_descuentos'],
            $perms['puede_ver_todas_cots'], $perms['puede_ver_todas_ventas'],
            $perms['puede_eliminar_items_venta'], $perms['puede_cancelar_recibos'],
        ]
    );
    echo json_encode(['ok'=>true, 'id'=>$nuevo]);
}
