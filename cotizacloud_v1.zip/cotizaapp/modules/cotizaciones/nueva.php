<?php
// ============================================================
//  CotizaApp — modules/cotizaciones/nueva.php
//  GET /cotizaciones/nueva
// ============================================================

defined('COTIZAAPP') or die;

$empresa    = Auth::empresa();
$usuario    = Auth::usuario();
$empresa_id = EMPRESA_ID;

// Cargar catálogo de artículos activos
$articulos = DB::query(
    "SELECT id, sku, titulo, descripcion, precio
     FROM articulos
     WHERE empresa_id = ? AND activo = 1
     ORDER BY orden ASC, titulo ASC",
    [$empresa_id]
);

// Cargar clientes
$clientes = DB::query(
    "SELECT id, nombre, telefono, email FROM clientes
     WHERE empresa_id = ? ORDER BY nombre ASC",
    [$empresa_id]
);

// Cargar cupones activos
$cupones = DB::query(
    "SELECT id, codigo, descripcion, porcentaje
     FROM cupones WHERE empresa_id = ? AND activo = 1
     ORDER BY codigo ASC",
    [$empresa_id]
);

// Defaults de empresa para la cotización nueva
$vigencia_default = (int)($empresa['cot_vigencia_dias'] ?? 30);
$fecha_hoy        = date('Y-m-d');
$fecha_vence      = date('Y-m-d', strtotime("+{$vigencia_default} days"));

$puede_editar_precios = Auth::puede('editar_precios');
$puede_descuentos     = Auth::puede('aplicar_descuentos');

// JSON para JS
$articulos_js = json_encode(array_map(fn($a) => [
    'id'          => (int)$a['id'],
    'sku'         => $a['sku'] ?? '',
    'titulo'      => $a['titulo'],
    'descripcion' => $a['descripcion'] ?? '',
    'precio'      => (float)$a['precio'],
], $articulos), JSON_HEX_TAG | JSON_HEX_APOS);

$clientes_js = json_encode(array_map(fn($c) => [
    'id'       => (int)$c['id'],
    'nombre'   => $c['nombre'],
    'telefono' => $c['telefono'],
    'email'    => $c['email'] ?? '',
], $clientes), JSON_HEX_TAG | JSON_HEX_APOS);

$empresa_js = json_encode([
    'moneda'        => $empresa['moneda'],
    'impuesto_modo' => $empresa['impuesto_modo'],
    'impuesto_pct'  => (float)$empresa['impuesto_pct'],
    'impuesto_label'=> $empresa['impuesto_label'] ?? 'IVA',
    'descuento_auto_pct'  => (float)($empresa['descuento_auto_pct'] ?? 0),
    'descuento_auto_dias' => (int)($empresa['descuento_auto_dias'] ?? 3),
], JSON_HEX_TAG);

$page_title = 'Nueva cotización';

// Este módulo tiene su propio layout (pantalla completa, sin sidebar)
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>Nueva cotización — <?= e($empresa['nombre']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
    :root {
        --bg:#f4f4f0; --white:#fff; --border:#e2e2dc; --border2:#c8c8c0;
        --text:#1a1a18; --t2:#4a4a46; --t3:#6a6a64;
        --g:#1a5c38; --g-bg:#eef7f2; --g-border:#b8ddc8; --g-light:#e6f4ed;
        --amb:#92400e; --amb-bg:#fef3c7;
        --blue:#1d4ed8; --blue-bg:#dbeafe;
        --danger:#c53030; --danger-bg:#fff5f5;
        --purple:#6d28d9; --purple-bg:#ede9fe;
        --r:12px; --r-sm:9px;
        --sh:0 1px 3px rgba(0,0,0,.06);
        --sh-md:0 4px 16px rgba(0,0,0,.08);
        --body:'Plus Jakarta Sans',sans-serif;
        --num:'DM Sans',sans-serif;
    }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: var(--body); background: var(--bg); color: var(--text); -webkit-font-smoothing: antialiased; }

    /* TOPBAR */
    .topbar { position:sticky; top:0; z-index:100; background:var(--white); border-bottom:1px solid var(--border); height:54px; display:flex; align-items:center; padding:0 20px; }
    .topbar-inner { width:100%; max-width:1200px; margin:0 auto; display:flex; align-items:center; justify-content:space-between; }
    .topbar-l { display:flex; align-items:center; gap:10px; }
    .back-btn { width:34px; height:34px; border-radius:8px; border:1px solid var(--border); background:var(--bg); display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--t2); text-decoration:none; transition:all .12s; }
    .back-btn:hover { border-color:var(--g); color:var(--g); }
    .topbar-title { font:700 15px var(--body); }
    .topbar-num   { font:500 12px var(--num); color:var(--t3); margin-left:6px; }

    /* LAYOUT */
    .page-wrap   { max-width:1200px; margin:0 auto; padding:0 20px; }
    .page-layout { display:flex; gap:24px; padding:24px 0 80px; align-items:flex-start; }
    .col-main    { flex:1; min-width:0; }
    .col-panel   { width:300px; flex-shrink:0; background:var(--white); border:1px solid var(--border); border-radius:var(--r); overflow:hidden; position:sticky; top:70px; box-shadow:var(--sh); }

    /* SECTION LABEL */
    .slabel { font:700 11px var(--body); letter-spacing:.06em; text-transform:uppercase; color:var(--t2); margin:24px 0 10px; display:flex; align-items:center; gap:10px; }
    .slabel::after { content:''; flex:1; height:1.5px; background:var(--border); }
    .slabel:first-child { margin-top:0; }

    /* CARD */
    .card { background:var(--white); border:1px solid var(--border); border-radius:var(--r); overflow:hidden; box-shadow:var(--sh); }
    .field { padding:12px 15px; border-bottom:1px solid var(--border); display:flex; flex-direction:column; gap:4px; }
    .field:last-child { border-bottom:none; }
    .field-lbl { font:700 10px var(--body); letter-spacing:.08em; text-transform:uppercase; color:var(--t3); }
    .field input, .field textarea {
        background:transparent; border:none; outline:none;
        font:500 15px var(--body); color:var(--text); width:100%;
        resize:none; line-height:1.5; padding:0;
    }
    .field input::placeholder, .field textarea::placeholder { color:var(--t3); font-weight:400; }

    /* CLIENTE */
    .client-btn { width:100%; padding:14px 16px; background:transparent; border:none; display:flex; align-items:center; gap:12px; cursor:pointer; text-align:left; transition:background .1s; }
    .client-btn:hover { background:var(--bg); }
    .client-avatar { width:40px; height:40px; border-radius:10px; background:var(--g); display:flex; align-items:center; justify-content:center; font:700 15px var(--body); color:#fff; flex-shrink:0; }
    .client-avatar.empty { background:var(--bg); border:1.5px dashed var(--border2); color:var(--t3); font-size:20px; }
    .client-name  { font:600 14px var(--body); color:var(--text); }
    .client-phone { font:400 12px var(--body); color:var(--t3); margin-top:2px; }
    .client-chevron { color:var(--t3); margin-left:auto; }

    /* ITEMS */
    .items-list { display:flex; flex-direction:column; gap:8px; }
    .item-card  { background:var(--white); border:1px solid var(--border); border-radius:var(--r); overflow:hidden; box-shadow:var(--sh); }
    .item-header { padding:9px 12px; background:var(--bg); border-bottom:1px solid var(--border); display:flex; align-items:center; gap:8px; }
    .item-num-wrap { display:flex; align-items:center; gap:5px; flex-shrink:0; }
    .item-arrow { width:26px; height:26px; border:1px solid var(--border2); background:var(--white); border-radius:6px; display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--t2); font-size:11px; transition:all .1s; flex-shrink:0; }
    .item-arrow:hover { background:var(--g-bg); border-color:var(--g); color:var(--g); }
    .item-num   { min-width:22px; height:22px; border-radius:5px; background:var(--border); display:flex; align-items:center; justify-content:center; font:600 11px var(--num); color:var(--t2); padding:0 4px; }
    .item-title-prev { flex:1; font:600 13px var(--body); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .item-amt-prev   { font:700 13px var(--num); color:var(--g); flex-shrink:0; }
    .item-del { width:26px; height:26px; border-radius:6px; border:none; background:transparent; display:flex; align-items:center; justify-content:center; color:var(--t3); cursor:pointer; font-size:14px; flex-shrink:0; transition:all .1s; }
    .item-del:hover { background:var(--danger-bg); color:var(--danger); }
    .item-field { padding:10px 13px; border-bottom:1px solid var(--border); display:flex; flex-direction:column; gap:3px; }
    .item-field:last-child { border-bottom:none; }
    .item-field-lbl { font:700 10px var(--body); letter-spacing:.08em; text-transform:uppercase; color:var(--t3); }
    .item-field input, .item-field textarea { background:transparent; border:none; outline:none; font:500 14px var(--body); color:var(--text); width:100%; resize:none; line-height:1.5; }
    .item-field input::placeholder, .item-field textarea::placeholder { color:var(--t3); font-weight:400; }
    .item-nums { display:grid; grid-template-columns:1fr 1fr 1fr; border-bottom:1px solid var(--border); }
    .item-nums .item-field { border-bottom:none; border-right:1px solid var(--border); }
    .item-nums .item-field:last-child { border-right:none; }
    .item-total input { color:var(--g) !important; font-weight:700 !important; font-family:var(--num) !important; }
    .item-field input[type=number] { font-family:var(--num); }
    <?php if (!$puede_editar_precios): ?>
    .item-field input[data-campo=precio] { pointer-events:none; color:var(--t3); }
    <?php endif; ?>

    .add-item-btn { width:100%; margin-top:8px; padding:14px; border-radius:var(--r); border:1.5px dashed var(--border2); background:transparent; display:flex; align-items:center; justify-content:center; gap:8px; font:600 14px var(--body); color:var(--t2); cursor:pointer; transition:all .15s; }
    .add-item-btn:hover { border-color:var(--g); color:var(--g); background:var(--g-bg); }

    /* PANEL DERECHO */
    .panel-section { padding:14px 16px; border-bottom:1px solid var(--border); }
    .panel-section:last-child { border-bottom:none; }
    .panel-lbl { font:700 10px var(--body); letter-spacing:.08em; text-transform:uppercase; color:var(--t3); margin-bottom:10px; }
    .panel-lbl-row { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; }
    .panel-lbl-row .panel-lbl { margin-bottom:0; }

    /* Toggle */
    .toggle-sm { position:relative; width:36px; height:20px; cursor:pointer; flex-shrink:0; display:inline-block; }
    .toggle-sm input { opacity:0; width:0; height:0; position:absolute; }
    .toggle-track { position:absolute; inset:0; border-radius:10px; background:var(--border2); transition:background .15s; }
    .toggle-thumb { position:absolute; top:3px; left:3px; width:14px; height:14px; border-radius:7px; background:#fff; transition:transform .15s; box-shadow:0 1px 3px rgba(0,0,0,.2); }
    .toggle-sm input:checked ~ .toggle-track { background:var(--g); }
    .toggle-sm input:checked ~ .toggle-thumb { transform:translateX(16px); }

    /* Cupón */
    .panel-coupon { display:flex; align-items:center; gap:8px; padding:9px 10px; border-radius:var(--r-sm); border:1px solid var(--border); background:var(--bg); cursor:pointer; transition:all .15s; margin-bottom:6px; }
    .panel-coupon:last-child { margin-bottom:0; }
    .panel-coupon.checked { background:var(--g-bg); border-color:var(--g); }
    .panel-check { width:18px; height:18px; border-radius:5px; border:1.5px solid var(--border2); background:#fff; display:flex; align-items:center; justify-content:center; flex-shrink:0; color:transparent; transition:all .15s; font-size:11px; }
    .panel-coupon.checked .panel-check { background:var(--g); border-color:var(--g); color:#fff; }
    .panel-coupon-code { font:600 12px var(--num); color:var(--text); }
    .panel-coupon-desc { font:400 11px var(--body); color:var(--t3); margin-top:1px; }
    .panel-coupon-pct  { font:700 13px var(--num); color:var(--g); flex-shrink:0; margin-left:auto; }

    /* Descuento auto */
    .panel-auto-fields { display:flex; flex-direction:column; gap:8px; margin-top:10px; }
    .panel-auto-row    { display:flex; align-items:center; gap:8px; }
    .panel-auto-lbl    { font:400 13px var(--body); color:var(--t2); flex:1; }
    .panel-auto-input  { width:64px; padding:7px 10px; background:var(--bg); border:1px solid var(--border2); border-radius:var(--r-sm); font:500 13px var(--num); color:var(--text); outline:none; text-align:right; }
    .panel-auto-input:focus { border-color:var(--g); }
    .panel-auto-sub    { font:400 11px var(--body); color:var(--t3); line-height:1.5; }

    /* Totales */
    .panel-t-row  { display:flex; justify-content:space-between; align-items:center; padding:7px 0; border-bottom:1px solid var(--border); }
    .panel-t-row:last-child { border-bottom:none; }
    .panel-t-lbl  { font:400 13px var(--body); color:var(--t2); }
    .panel-t-val  { font:500 14px var(--num); color:var(--text); }
    .panel-t-row.disc .panel-t-lbl, .panel-t-row.disc .panel-t-val { color:var(--amb); }
    .panel-t-row.final .panel-t-lbl { font:700 15px var(--body); color:var(--text); }
    .panel-t-row.final .panel-t-val { font:700 18px var(--num); color:var(--g); }

    /* Historial */
    .visit-row   { display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:1px solid var(--border); }
    .visit-row:last-child { border-bottom:none; }
    .visit-dot   { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
    .visit-time  { font:600 12px var(--body); color:var(--text); }
    .visit-detail{ font:400 11px var(--body); color:var(--t3); margin-top:1px; }
    .visit-dur   { font:500 11px var(--num); color:var(--t3); flex-shrink:0; }
    .visit-empty { text-align:center; padding:12px 0; color:var(--t3); font:400 12px var(--body); line-height:1.6; }

    /* Botón guardar */
    .btn-guardar { width:100%; padding:14px; border-radius:var(--r-sm); border:none; background:var(--g); font:700 15px var(--body); color:#fff; cursor:pointer; transition:opacity .15s; }
    .btn-guardar:hover    { opacity:.9; }
    .btn-guardar:disabled { opacity:.5; cursor:not-allowed; }

    /* Archivos */
    .panel-drop { border:1.5px dashed var(--border2); border-radius:var(--r-sm); padding:13px; text-align:center; cursor:pointer; transition:all .15s; }
    .panel-drop:hover { border-color:var(--g); background:var(--g-bg); }
    .panel-file-item { display:flex; align-items:center; gap:8px; padding:7px 10px; background:var(--bg); border:1px solid var(--border); border-radius:var(--r-sm); margin-top:6px; }
    .panel-file-name { flex:1; font:500 12px var(--body); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .panel-file-size { font:400 10px var(--num); color:var(--t3); flex-shrink:0; }
    .panel-file-rm   { background:none; border:none; color:var(--t3); cursor:pointer; font-size:14px; flex-shrink:0; padding:0 2px; }
    .panel-file-rm:hover { color:var(--danger); }

    /* Notes */
    .panel-notes textarea { width:100%; background:var(--bg); border:1px solid var(--border); border-radius:var(--r-sm); padding:10px 12px; font:400 13px var(--body); color:var(--text); resize:none; outline:none; min-height:60px; line-height:1.5; }
    .panel-notes textarea:focus { border-color:var(--g); }
    .panel-notes textarea::placeholder { color:var(--t3); }

    /* SHEETS */
    .sh-overlay  { position:fixed; inset:0; z-index:200; background:rgba(0,0,0,.4); backdrop-filter:blur(4px); opacity:0; pointer-events:none; transition:opacity .25s; }
    .sh-overlay.open { opacity:1; pointer-events:all; }
    .bottom-sheet { position:fixed; bottom:0; left:0; right:0; z-index:201; background:var(--white); border-radius:20px 20px 0 0; max-height:90vh; display:flex; flex-direction:column; transform:translateY(100%); transition:transform .3s cubic-bezier(.32,0,.15,1); box-shadow:0 -8px 32px rgba(0,0,0,.1); max-width:720px; margin:0 auto; }
    .bottom-sheet.open { transform:translateY(0); }
    .sh-handle   { width:34px; height:4px; border-radius:2px; background:var(--border2); margin:12px auto 0; flex-shrink:0; }
    .sh-header   { padding:14px 18px 10px; display:flex; align-items:center; justify-content:space-between; flex-shrink:0; }
    .sh-title    { font:800 17px var(--body); }
    .sh-close    { width:30px; height:30px; border-radius:999px; border:none; background:var(--bg); cursor:pointer; color:var(--t2); display:flex; align-items:center; justify-content:center; font-size:15px; }
    .sh-search   { padding:0 16px 10px; flex-shrink:0; }
    .sh-search-wrap { display:flex; align-items:center; gap:8px; background:var(--bg); border:1px solid var(--border); border-radius:var(--r-sm); padding:10px 13px; }
    .sh-search-wrap input { flex:1; background:transparent; border:none; outline:none; font:400 15px var(--body); color:var(--text); }
    .sh-list     { overflow-y:auto; flex:1; padding:0 16px 32px; }
    .sh-item     { display:flex; align-items:center; gap:12px; padding:12px; border-radius:var(--r-sm); cursor:pointer; border:1px solid transparent; margin-bottom:6px; transition:all .12s; }
    .sh-item:hover { background:var(--g-bg); border-color:var(--g-border); }
    .sh-item-body { flex:1; }
    .sh-item-title { font:600 14px var(--body); margin-bottom:2px; }
    .sh-item-sku   { font:400 11px var(--num); color:var(--t3); }
    .sh-item-desc  { font:400 12px var(--body); color:var(--t3); margin-top:2px; }
    .sh-item-price { font:700 15px var(--num); color:var(--g); flex-shrink:0; }
    .sh-client-item { display:flex; align-items:center; gap:12px; padding:12px; border-radius:var(--r-sm); cursor:pointer; margin-bottom:6px; transition:background .12s; }
    .sh-client-item:hover { background:var(--g-bg); }
    .sh-client-avatar { width:40px; height:40px; border-radius:10px; background:var(--g); display:flex; align-items:center; justify-content:center; font:700 15px var(--body); color:#fff; flex-shrink:0; }
    .sh-tabs { display:flex; background:var(--bg); border:1px solid var(--border); border-radius:var(--r-sm); padding:3px; margin:0 16px 12px; flex-shrink:0; }
    .sh-tab  { flex:1; padding:8px; text-align:center; border-radius:7px; font:600 13px var(--body); color:var(--t2); cursor:pointer; border:none; background:transparent; transition:all .15s; }
    .sh-tab.active { background:var(--white); color:var(--g); box-shadow:0 1px 3px rgba(0,0,0,.08); }
    .nc-field { padding:0 16px 12px; flex-shrink:0; }
    .nc-lbl   { font:700 10px var(--body); letter-spacing:.08em; text-transform:uppercase; color:var(--t3); margin-bottom:6px; display:block; }
    .nc-input { width:100%; background:var(--bg); border:1.5px solid var(--border); border-radius:var(--r-sm); padding:10px 13px; font:400 15px var(--body); color:var(--text); outline:none; transition:border-color .15s; }
    .nc-input:focus { border-color:var(--g); }
    .nc-btn   { width:calc(100% - 32px); margin:0 16px 16px; padding:14px; background:var(--g); border:none; border-radius:var(--r-sm); font:700 15px var(--body); color:#fff; cursor:pointer; }

    /* PANEL MÓVIL */
    .mobile-panel { display:none; margin-top:8px; }
    .mob-section  { background:var(--white); border:1px solid var(--border); border-radius:var(--r); overflow:hidden; box-shadow:var(--sh); margin-bottom:8px; }
    .mob-sec-hdr  { padding:14px 16px; display:flex; align-items:center; justify-content:space-between; cursor:pointer; user-select:none; }
    .mob-sec-title { font:700 14px var(--body); color:var(--text); }
    .mob-sec-arrow { color:var(--t3); font-size:16px; transition:transform .2s; }
    .mob-sec-body  { display:none; border-top:1px solid var(--border); }
    .mob-section.open .mob-sec-arrow { transform:rotate(90deg); }
    .mob-section.open .mob-sec-body  { display:block; }
    .mob-sec-inner { padding:14px 16px; }

    /* Sticky bottom móvil */
    .sticky-bottom { position:fixed; bottom:0; left:0; right:0; z-index:50; background:var(--white); border-top:1px solid var(--border); padding:12px 20px 24px; display:none; box-shadow:0 -4px 16px rgba(0,0,0,.06); }
    .sticky-total-lbl { font:400 11px var(--body); color:var(--t3); }
    .sticky-total-val { font:700 20px var(--num); color:var(--text); }
    .btn-gen { width:100%; padding:13px; border-radius:var(--r-sm); border:none; background:var(--g); font:700 15px var(--body); color:#fff; cursor:pointer; margin-top:10px; }

    @media(max-width:820px) {
        .col-panel     { display:none; }
        .mobile-panel  { display:block; }
        .sticky-bottom { display:block !important; }
        .page-layout   { padding:16px 0 120px; }
        .page-wrap     { padding:0 14px; }
        .item-field input, .item-field textarea { font-size:16px; }
        .item-arrow { width:34px; height:34px; font-size:14px; }
    }
    @media(min-width:821px) {
        .sticky-bottom { display:none !important; }
    }
    </style>
</head>
<body>

<!-- TOPBAR -->
<div class="topbar">
    <div class="topbar-inner">
        <div class="topbar-l">
            <a href="/cotizaciones" class="back-btn" title="Volver">
                <i data-feather="arrow-left" style="width:16px;height:16px;"></i>
            </a>
            <div>
                <div class="topbar-title">Nueva cotización</div>
                <span class="topbar-num" id="cot-numero">—</span>
            </div>
        </div>
        <button class="back-btn" style="width:auto;padding:0 14px;gap:6px;display:flex;font:600 13px var(--body);"
                onclick="guardarCotizacion(true)" id="btn-preview">
            <i data-feather="eye" style="width:14px;height:14px;"></i> Vista previa
        </button>
    </div>
</div>

<div class="page-wrap">
<div class="page-layout">

    <!-- COLUMNA PRINCIPAL -->
    <div class="col-main">

        <div class="slabel">Cliente</div>
        <div class="card">
            <button class="client-btn" onclick="openSheet('clientSheet','clientOverlay')" id="client-btn">
                <div class="client-avatar empty" id="client-avatar">+</div>
                <div style="flex:1;">
                    <div class="client-name" id="client-name" style="color:var(--t3)">Seleccionar cliente</div>
                    <div class="client-phone" id="client-phone"></div>
                </div>
                <i data-feather="chevron-right" style="width:16px;height:16px;" class="client-chevron"></i>
            </button>
        </div>

        <div class="slabel">Proyecto</div>
        <div class="card">
            <div class="field">
                <div class="field-lbl">Título <span style="color:var(--danger)">*</span></div>
                <input type="text" id="cot-titulo" placeholder="Ej. Cocina L Escuadra 4.25×5.25"
                       oninput="actualizarEstado()">
            </div>
            <div style="display:flex">
                <div class="field" style="flex:1;border-bottom:none;border-right:1px solid var(--border)">
                    <div class="field-lbl">Fecha</div>
                    <input type="date" id="cot-fecha" value="<?= $fecha_hoy ?>">
                </div>
                <div class="field" style="flex:1;border-bottom:none">
                    <div class="field-lbl">Vence</div>
                    <input type="date" id="cot-vence" value="<?= $fecha_vence ?>">
                </div>
            </div>
        </div>

        <div class="slabel">Artículos</div>
        <div class="items-list" id="items-list"></div>

        <button class="add-item-btn" onclick="openSheet('catalogSheet','catalogOverlay')">
            <span style="font-size:18px">+</span> Agregar artículo
        </button>

        <!-- PANEL MÓVIL -->
        <div class="mobile-panel">
            <div class="slabel" style="margin-top:24px">Opciones</div>

            <?php if (!empty($cupones) && $puede_descuentos): ?>
            <div class="mob-section">
                <div class="mob-sec-hdr" onclick="toggleMob(this)">
                    <span class="mob-sec-title">Cupones</span>
                    <span class="mob-sec-arrow">›</span>
                </div>
                <div class="mob-sec-body">
                    <div class="mob-sec-inner" id="cupones-mob"></div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($puede_descuentos): ?>
            <div class="mob-section">
                <div class="mob-sec-hdr" onclick="toggleMob(this)">
                    <span class="mob-sec-title">Descuento automático</span>
                    <span class="mob-sec-arrow">›</span>
                </div>
                <div class="mob-sec-body">
                    <div class="mob-sec-inner" id="desc-auto-mob">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                            <span style="font:400 14px var(--body);color:var(--t2)">Activar descuento</span>
                            <label class="toggle-sm"><input type="checkbox" id="desc-auto-toggle-mob" onchange="syncToggle('mob')"><div class="toggle-track"></div><div class="toggle-thumb"></div></label>
                        </div>
                        <div class="panel-auto-fields" id="desc-auto-fields-mob" style="display:none">
                            <div class="panel-auto-row"><span class="panel-auto-lbl">Porcentaje</span><input type="number" class="panel-auto-input" id="desc-pct-mob" value="0" min="0" max="100" oninput="syncDescAuto('mob')"><span style="font:400 12px var(--body);color:var(--t3)">%</span></div>
                            <div class="panel-auto-row"><span class="panel-auto-lbl">Expira en</span><input type="number" class="panel-auto-input" id="desc-dias-mob" value="3" min="1" oninput="syncDescAuto('mob')"><span style="font:400 12px var(--body);color:var(--t3)">días</span></div>
                            <div class="panel-auto-sub">El cliente ve el descuento con cronómetro.</div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="mob-section">
                <div class="mob-sec-hdr" onclick="toggleMob(this)">
                    <span class="mob-sec-title">Notas para el cliente</span>
                    <span class="mob-sec-arrow">›</span>
                </div>
                <div class="mob-sec-body">
                    <div class="mob-sec-inner">
                        <div class="panel-notes"><textarea id="notas-cliente-mob" placeholder="Visible para el cliente..." oninput="autoResize(this);syncNotas('mob')"></textarea></div>
                    </div>
                </div>
            </div>

            <div class="mob-section">
                <div class="mob-sec-hdr" onclick="toggleMob(this)">
                    <span class="mob-sec-title">Notas internas</span>
                    <span class="mob-sec-arrow">›</span>
                </div>
                <div class="mob-sec-body">
                    <div class="mob-sec-inner">
                        <div class="panel-notes"><textarea id="notas-internas-mob" placeholder="Solo visible para el asesor..." oninput="autoResize(this);syncNotas('mob')"></textarea></div>
                    </div>
                </div>
            </div>

            <div class="mob-section">
                <div class="mob-sec-hdr" onclick="toggleMob(this)">
                    <span class="mob-sec-title">Historial de visitas</span>
                    <span class="mob-sec-arrow">›</span>
                </div>
                <div class="mob-sec-body">
                    <div class="mob-sec-inner">
                        <div class="visit-empty">Sin visitas aún<br>Se registran cuando el cliente abre la cotización</div>
                    </div>
                </div>
            </div>
        </div><!-- /mobile-panel -->

    </div><!-- /col-main -->

    <!-- PANEL DERECHO (desktop) -->
    <div class="col-panel">

        <?php if (!empty($cupones) && $puede_descuentos): ?>
        <div class="panel-section">
            <div class="panel-lbl">Cupones</div>
            <div id="cupones-desktop">
                <?php foreach ($cupones as $cup): ?>
                <div class="panel-coupon" data-cupon-id="<?= (int)$cup['id'] ?>"
                     data-cupon-codigo="<?= e($cup['codigo']) ?>"
                     data-cupon-pct="<?= (float)$cup['porcentaje'] ?>"
                     onclick="toggleCupon(this)">
                    <div class="panel-check">✓</div>
                    <div style="flex:1;min-width:0">
                        <div class="panel-coupon-code"><?= e($cup['codigo']) ?></div>
                        <?php if ($cup['descripcion']): ?>
                        <div class="panel-coupon-desc"><?= e($cup['descripcion']) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="panel-coupon-pct">-<?= number_format($cup['porcentaje'],1) ?>%</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($puede_descuentos): ?>
        <div class="panel-section">
            <div class="panel-lbl-row">
                <span class="panel-lbl">Descuento automático</span>
                <label class="toggle-sm">
                    <input type="checkbox" id="desc-auto-toggle-desk" onchange="syncToggle('desk')">
                    <div class="toggle-track"></div>
                    <div class="toggle-thumb"></div>
                </label>
            </div>
            <div class="panel-auto-fields" id="desc-auto-fields-desk" style="display:none">
                <div class="panel-auto-row">
                    <span class="panel-auto-lbl">Porcentaje</span>
                    <input type="number" class="panel-auto-input" id="desc-pct-desk" value="0" min="0" max="100" oninput="syncDescAuto('desk')">
                    <span style="font:400 12px var(--body);color:var(--t3)">%</span>
                </div>
                <div class="panel-auto-row">
                    <span class="panel-auto-lbl">Expira en</span>
                    <input type="number" class="panel-auto-input" id="desc-dias-desk" value="3" min="1" oninput="syncDescAuto('desk')">
                    <span style="font:400 12px var(--body);color:var(--t3)">días</span>
                </div>
                <div class="panel-auto-sub">El cliente ve el descuento con cronómetro, sin código.</div>
            </div>
        </div>
        <?php endif; ?>

        <div class="panel-section">
            <div class="panel-lbl">Totales</div>
            <div class="panel-t-row">
                <span class="panel-t-lbl">Subtotal</span>
                <span class="panel-t-val" id="total-subtotal">$0.00</span>
            </div>
            <div class="panel-t-row disc" id="row-cupon" style="display:none">
                <span class="panel-t-lbl" id="lbl-cupon">Cupón</span>
                <span class="panel-t-val" id="total-cupon">-$0.00</span>
            </div>
            <div class="panel-t-row disc" id="row-desc-auto" style="display:none">
                <span class="panel-t-lbl">Descuento</span>
                <span class="panel-t-val" id="total-desc-auto">-$0.00</span>
            </div>
            <?php if ($empresa['impuesto_modo'] !== 'ninguno'): ?>
            <div class="panel-t-row" id="row-impuesto">
                <span class="panel-t-lbl"><?= e($empresa['impuesto_label'] ?? 'IVA') ?></span>
                <span class="panel-t-val" id="total-impuesto">$0.00</span>
            </div>
            <?php endif; ?>
            <div class="panel-t-row final">
                <span class="panel-t-lbl">Total</span>
                <span class="panel-t-val" id="total-final">$0.00</span>
            </div>
        </div>

        <div class="panel-section">
            <div class="panel-lbl">Notas para el cliente</div>
            <div class="panel-notes">
                <textarea id="notas-cliente-desk" rows="3"
                          placeholder="Visible para el cliente..."
                          oninput="autoResize(this);syncNotas('desk')"></textarea>
            </div>
        </div>

        <div class="panel-section">
            <div class="panel-lbl">Notas internas</div>
            <div class="panel-notes">
                <textarea id="notas-internas-desk" rows="2"
                          placeholder="Solo visible para el asesor..."
                          oninput="autoResize(this);syncNotas('desk')"></textarea>
            </div>
        </div>

        <div class="panel-section">
            <div class="panel-lbl" style="margin-bottom:8px">Historial de visitas</div>
            <div class="visit-empty">Sin visitas aún.<br>Se registran cuando el cliente abre la cotización.</div>
        </div>

        <div class="panel-section">
            <button class="btn-guardar" onclick="guardarCotizacion(false)" id="btn-guardar">
                Guardar borrador
            </button>
        </div>
    </div><!-- /col-panel -->

</div><!-- /page-layout -->
</div><!-- /page-wrap -->

<!-- STICKY BOTTOM MÓVIL -->
<div class="sticky-bottom">
    <div class="sticky-total-lbl">Total estimado</div>
    <div class="sticky-total-val" id="total-mob">$0.00</div>
    <button class="btn-gen" onclick="guardarCotizacion(false)">Guardar borrador</button>
</div>

<!-- ══ SHEET: Catálogo ══ -->
<div class="sh-overlay" id="catalogOverlay" onclick="closeSheet('catalogSheet','catalogOverlay')"></div>
<div class="bottom-sheet" id="catalogSheet">
    <div class="sh-handle"></div>
    <div class="sh-header">
        <span class="sh-title">Agregar artículo</span>
        <button class="sh-close" onclick="closeSheet('catalogSheet','catalogOverlay')">✕</button>
    </div>
    <div class="sh-search">
        <div class="sh-search-wrap">
            <i data-feather="search" style="width:15px;height:15px;color:var(--t3);flex-shrink:0"></i>
            <input type="text" placeholder="Buscar en catálogo..." id="catalog-search"
                   oninput="filtrarCatalogo(this.value)">
        </div>
    </div>
    <button style="margin:0 16px 10px;width:calc(100% - 32px);padding:12px 14px;border-radius:var(--r-sm);border:1.5px dashed var(--border2);background:transparent;display:flex;align-items:center;gap:8px;font:600 14px var(--body);color:var(--t2);cursor:pointer;flex-shrink:0;transition:all .15s;"
            onmouseover="this.style.borderColor='var(--g)';this.style.color='var(--g)'"
            onmouseout="this.style.borderColor='var(--border2)';this.style.color='var(--t2)'"
            onclick="agregarItemVacio()">
        <span style="font-size:18px">+</span> Ítem libre (sin catálogo)
    </button>
    <div class="sh-list" id="catalog-list"></div>
</div>

<!-- ══ SHEET: Cliente ══ -->
<div class="sh-overlay" id="clientOverlay" onclick="closeSheet('clientSheet','clientOverlay')"></div>
<div class="bottom-sheet" id="clientSheet">
    <div class="sh-handle"></div>
    <div class="sh-header">
        <span class="sh-title">Seleccionar cliente</span>
        <button class="sh-close" onclick="closeSheet('clientSheet','clientOverlay')">✕</button>
    </div>
    <div class="sh-tabs">
        <button class="sh-tab active" id="tab-existing" onclick="switchClientTab('existing')">Clientes</button>
        <button class="sh-tab" id="tab-new" onclick="switchClientTab('new')">Nuevo cliente</button>
    </div>
    <!-- Existente -->
    <div id="tab-existing-panel">
        <div class="sh-search">
            <div class="sh-search-wrap">
                <i data-feather="search" style="width:15px;height:15px;color:var(--t3);flex-shrink:0"></i>
                <input type="text" placeholder="Buscar cliente..." id="client-search"
                       oninput="filtrarClientes(this.value)">
            </div>
        </div>
        <div class="sh-list" id="client-list"></div>
    </div>
    <!-- Nuevo -->
    <div id="tab-new-panel" style="display:none;overflow-y:auto;flex:1;padding-bottom:20px;">
        <div class="nc-field">
            <label class="nc-lbl">Nombre <span style="color:var(--danger)">*</span></label>
            <input type="text" class="nc-input" id="nc-nombre" placeholder="Nombre completo">
        </div>
        <div class="nc-field">
            <label class="nc-lbl">Teléfono <span style="color:var(--danger)">*</span></label>
            <input type="tel" class="nc-input" id="nc-telefono" placeholder="662 123 4567">
        </div>
        <div class="nc-field">
            <label class="nc-lbl">Correo (opcional)</label>
            <input type="email" class="nc-input" id="nc-email" placeholder="nombre@correo.com">
        </div>
        <button class="nc-btn" onclick="crearClienteNuevo()">Agregar cliente</button>
    </div>
</div>

<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
// ─── Datos del servidor ─────────────────────────────────
const ARTICULOS   = <?= $articulos_js ?>;
const CLIENTES    = <?= $clientes_js ?>;
const EMPRESA_CFG = <?= $empresa_js ?>;
const CSRF_TOKEN  = '<?= csrf_token() ?>';
const PUEDE_PRECIOS    = <?= $puede_editar_precios ? 'true' : 'false' ?>;
const PUEDE_DESCUENTOS = <?= $puede_descuentos ? 'true' : 'false' ?>;

// ─── Estado global ──────────────────────────────────────
let clienteSeleccionado = null;
let cuponSeleccionado   = null; // {id, codigo, pct}
let descAutoActivo      = false;
let descAutoPct         = EMPRESA_CFG.descuento_auto_pct || 0;
let descAutoDias        = EMPRESA_CFG.descuento_auto_dias || 3;

// ─── Init ───────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    feather.replace();
    renderCatalogList('');
    renderClientList('');
    calcularTotales();

    // Defaults de descuento auto desde empresa
    if (descAutoPct > 0) {
        setVal('desc-pct-desk', descAutoPct);
        setVal('desc-pct-mob',  descAutoPct);
    }
    setVal('desc-dias-desk', descAutoDias);
    setVal('desc-dias-mob',  descAutoDias);
});

// ─── Sheets ─────────────────────────────────────────────
function openSheet(s, o) {
    document.getElementById(o).classList.add('open');
    document.getElementById(s).classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeSheet(s, o) {
    document.getElementById(o).classList.remove('open');
    document.getElementById(s).classList.remove('open');
    document.body.style.overflow = '';
}

// ─── Catálogo ───────────────────────────────────────────
function renderCatalogList(filtro) {
    const q    = filtro.toLowerCase();
    const list = ARTICULOS.filter(a =>
        !q || a.titulo.toLowerCase().includes(q) ||
              (a.sku && a.sku.toLowerCase().includes(q))
    );
    const el = document.getElementById('catalog-list');
    if (!list.length) {
        el.innerHTML = '<div style="text-align:center;padding:24px;color:var(--t3);font-size:13px">Sin resultados</div>';
        return;
    }
    el.innerHTML = list.map(a => `
        <div class="sh-item" onclick="agregarDesde(${a.id})">
            <div style="flex:1;">
                <div class="sh-item-title">${esc(a.titulo)}</div>
                ${a.sku ? `<div class="sh-item-sku">${esc(a.sku)}</div>` : ''}
                ${a.descripcion ? `<div class="sh-item-desc">${esc(strip(a.descripcion))}</div>` : ''}
            </div>
            <div class="sh-item-price">${fmt(a.precio)}</div>
        </div>
    `).join('');
}

function filtrarCatalogo(val) { renderCatalogList(val); }

function agregarDesde(id) {
    const a = ARTICULOS.find(x => x.id === id);
    if (!a) return;
    agregarItem(a.titulo, a.sku || '', a.descripcion || '', a.precio, id);
    closeSheet('catalogSheet', 'catalogOverlay');
}

function agregarItemVacio() {
    agregarItem('', '', '', 0, null);
    closeSheet('catalogSheet', 'catalogOverlay');
    setTimeout(() => {
        const items = document.querySelectorAll('#items-list .item-card');
        const last  = items[items.length - 1];
        if (last) last.querySelector('input[data-campo=titulo]').focus();
    }, 100);
}

// ─── Items ──────────────────────────────────────────────
let itemCounter = 0;

function agregarItem(titulo, sku, desc, precio, articulo_id) {
    itemCounter++;
    const id  = 'item-' + itemCounter;
    const amt = titulo ? fmt(precio) : '$0.00';
    const html = `
    <div class="item-card" data-articulo-id="${articulo_id || ''}" id="${id}">
        <div class="item-header">
            <div class="item-num-wrap">
                <button class="item-arrow" onclick="moverItem(this,-1)" title="Subir">▲</button>
                <div class="item-num">?</div>
                <button class="item-arrow" onclick="moverItem(this,1)" title="Bajar">▼</button>
            </div>
            <div class="item-title-prev">${esc(titulo) || 'Sin nombre'}</div>
            <div class="item-amt-prev">${amt}</div>
            <button class="item-del" onclick="eliminarItem(this)" title="Eliminar">✕</button>
        </div>
        <div class="item-body">
            <div class="item-field">
                <div class="item-field-lbl">Nombre</div>
                <input type="text" data-campo="titulo" value="${esc(titulo)}"
                       placeholder="Nombre del artículo"
                       oninput="updateItemPreview(this)">
            </div>
            <div class="item-field">
                <div class="item-field-lbl">SKU (opcional)</div>
                <input type="text" data-campo="sku" value="${esc(sku)}" placeholder="Ej. EST-01">
            </div>
            <div class="item-field">
                <div class="item-field-lbl">Descripción (opcional)</div>
                <textarea data-campo="descripcion" oninput="autoResize(this)">${esc(desc)}</textarea>
            </div>
            <div class="item-nums">
                <div class="item-field">
                    <div class="item-field-lbl">Cantidad</div>
                    <input type="number" data-campo="cantidad" value="1" min="0" step="any" oninput="calcItemTotal(this)">
                </div>
                <div class="item-field">
                    <div class="item-field-lbl">Precio unit.</div>
                    <input type="number" data-campo="precio" value="${precio}" min="0" step="any"
                           oninput="calcItemTotal(this)"
                           ${!PUEDE_PRECIOS ? 'readonly style="color:var(--t3)"' : ''}>
                </div>
                <div class="item-field item-total">
                    <div class="item-field-lbl">Total</div>
                    <input type="text" data-campo="total" value="${amt}" readonly>
                </div>
            </div>
        </div>
    </div>`;

    const list = document.getElementById('items-list');
    list.insertAdjacentHTML('beforeend', html);
    list.lastElementChild.querySelectorAll('textarea').forEach(t => autoResize(t));
    renumerarItems();
    calcularTotales();
    list.lastElementChild.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function eliminarItem(btn) {
    btn.closest('.item-card').remove();
    renumerarItems();
    calcularTotales();
}

function moverItem(btn, dir) {
    const card  = btn.closest('.item-card');
    const list  = document.getElementById('items-list');
    const items = [...list.children];
    const idx   = items.indexOf(card);
    const target = items[idx + dir];
    if (!target) return;
    dir === -1 ? list.insertBefore(card, target) : list.insertBefore(target, card);
    renumerarItems();
}

function renumerarItems() {
    document.querySelectorAll('#items-list .item-card').forEach((c, i) => {
        c.querySelector('.item-num').textContent = i + 1;
    });
}

function updateItemPreview(input) {
    const card = input.closest('.item-card');
    card.querySelector('.item-title-prev').textContent = input.value || 'Sin nombre';
}

function calcItemTotal(input) {
    const card  = input.closest('.item-card');
    const cant  = parseFloat(card.querySelector('[data-campo=cantidad]').value) || 0;
    const precio = parseFloat(card.querySelector('[data-campo=precio]').value)   || 0;
    const total = cant * precio;
    card.querySelector('[data-campo=total]').value   = fmt(total);
    card.querySelector('.item-amt-prev').textContent = fmt(total);
    calcularTotales();
}

// ─── Cálculo de totales ─────────────────────────────────
function calcularTotales() {
    // Subtotal de items
    let subtotal = 0;
    document.querySelectorAll('#items-list .item-card').forEach(card => {
        const cant  = parseFloat(card.querySelector('[data-campo=cantidad]')?.value) || 0;
        const precio = parseFloat(card.querySelector('[data-campo=precio]')?.value)  || 0;
        subtotal += cant * precio;
    });

    // Descuentos
    let baseImpuesto = subtotal;

    // Cupón
    let cuponAmt = 0;
    if (cuponSeleccionado) {
        cuponAmt    = subtotal * (cuponSeleccionado.pct / 100);
        baseImpuesto -= cuponAmt;
        document.getElementById('row-cupon').style.display = '';
        document.getElementById('lbl-cupon').textContent   = 'Cupón ' + cuponSeleccionado.codigo;
        document.getElementById('total-cupon').textContent = '-' + fmt(cuponAmt);
    } else {
        document.getElementById('row-cupon').style.display = 'none';
    }

    // Descuento auto
    let descAutoAmt = 0;
    const rowDescAuto = document.getElementById('row-desc-auto');
    if (descAutoActivo && descAutoPct > 0) {
        descAutoAmt  = baseImpuesto * (descAutoPct / 100);
        baseImpuesto -= descAutoAmt;
        rowDescAuto.style.display = '';
        document.getElementById('total-desc-auto').textContent = '-' + fmt(descAutoAmt);
    } else {
        rowDescAuto.style.display = 'none';
    }

    // Impuesto
    let impuestoAmt = 0;
    const modo = EMPRESA_CFG.impuesto_modo;
    const pct  = EMPRESA_CFG.impuesto_pct / 100;
    if (modo === 'suma') {
        impuestoAmt = baseImpuesto * pct;
    } else if (modo === 'incluido') {
        impuestoAmt = baseImpuesto - (baseImpuesto / (1 + pct));
    }

    const total = modo === 'suma'
        ? baseImpuesto + impuestoAmt
        : baseImpuesto; // incluido o ninguno

    // Actualizar DOM
    setText('total-subtotal', fmt(subtotal));
    if (document.getElementById('total-impuesto')) {
        setText('total-impuesto', (modo === 'incluido' ? '' : '+') + fmt(impuestoAmt));
    }
    setText('total-final', fmt(total));
    setText('total-mob',   fmt(total));
}

// ─── Cliente ────────────────────────────────────────────
function renderClientList(filtro) {
    const q  = filtro.toLowerCase();
    const el = document.getElementById('client-list');
    const lista = CLIENTES.filter(c =>
        !q || c.nombre.toLowerCase().includes(q) ||
              c.telefono.includes(q)
    );
    if (!lista.length) {
        el.innerHTML = '<div style="text-align:center;padding:24px;color:var(--t3);font-size:13px">Sin clientes</div>';
        return;
    }
    el.innerHTML = lista.map(c => `
        <div class="sh-client-item" onclick="seleccionarCliente(${c.id})">
            <div class="sh-client-avatar">${esc(c.nombre.charAt(0).toUpperCase())}</div>
            <div>
                <div style="font:600 14px var(--body)">${esc(c.nombre)}</div>
                <div style="font:400 12px var(--body);color:var(--t3)">${esc(c.telefono)}</div>
            </div>
        </div>
    `).join('');
}

function filtrarClientes(val) { renderClientList(val); }

function seleccionarCliente(id) {
    const c = CLIENTES.find(x => x.id === id);
    if (!c) return;
    clienteSeleccionado = c;

    const iniciales = c.nombre.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
    const avatar    = document.getElementById('client-avatar');
    avatar.className    = 'client-avatar';
    avatar.textContent  = iniciales;

    document.getElementById('client-name').style.color = '';
    document.getElementById('client-name').textContent  = c.nombre;
    document.getElementById('client-phone').textContent = c.telefono;

    closeSheet('clientSheet', 'clientOverlay');
}

function switchClientTab(tab) {
    document.getElementById('tab-existing-panel').style.display = tab === 'existing' ? '' : 'none';
    document.getElementById('tab-new-panel').style.display      = tab === 'new'      ? '' : 'none';
    document.getElementById('tab-existing').classList.toggle('active', tab === 'existing');
    document.getElementById('tab-new').classList.toggle('active', tab === 'new');
}

async function crearClienteNuevo() {
    const nombre   = document.getElementById('nc-nombre').value.trim();
    const telefono = document.getElementById('nc-telefono').value.trim();
    const email    = document.getElementById('nc-email').value.trim();

    if (!nombre)   { alert('El nombre es requerido'); return; }
    if (!telefono) { alert('El teléfono es requerido'); return; }

    try {
        const r = await fetch('/clientes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN },
            body: JSON.stringify({ nombre, telefono, email, _action: 'crear' })
        });
        const data = await r.json();
        if (!data.ok) { alert(data.error || 'Error al crear cliente'); return; }

        const c = { id: data.data.id, nombre, telefono, email };
        CLIENTES.unshift(c);
        seleccionarCliente(c.id);
        document.getElementById('nc-nombre').value   = '';
        document.getElementById('nc-telefono').value = '';
        document.getElementById('nc-email').value    = '';
    } catch (e) {
        alert('Error de conexión');
    }
}

// ─── Cupones ────────────────────────────────────────────
function toggleCupon(el) {
    const id     = parseInt(el.dataset.cuponId);
    const codigo = el.dataset.cuponCodigo;
    const pct    = parseFloat(el.dataset.cuponPct);

    if (el.classList.contains('checked')) {
        // Deseleccionar
        el.classList.remove('checked');
        cuponSeleccionado = null;
    } else {
        // Deseleccionar todos
        document.querySelectorAll('.panel-coupon.checked').forEach(x => x.classList.remove('checked'));
        el.classList.add('checked');
        cuponSeleccionado = { id, codigo, pct };
    }
    calcularTotales();
}

// ─── Descuento automático ───────────────────────────────
function syncToggle(from) {
    const srcId  = 'desc-auto-toggle-' + from;
    const dstId  = 'desc-auto-toggle-' + (from === 'desk' ? 'mob' : 'desk');
    const val    = document.getElementById(srcId)?.checked;

    const dst = document.getElementById(dstId);
    if (dst) dst.checked = val;

    descAutoActivo = val;
    ['desk','mob'].forEach(s => {
        const f = document.getElementById('desc-auto-fields-' + s);
        if (f) f.style.display = val ? 'flex' : 'none';
    });
    calcularTotales();
}

function syncDescAuto(from) {
    const pct  = parseFloat(document.getElementById('desc-pct-'  + from)?.value) || 0;
    const dias = parseInt(document.getElementById('desc-dias-' + from)?.value)    || 1;
    const other = from === 'desk' ? 'mob' : 'desk';

    setVal('desc-pct-'  + other, pct);
    setVal('desc-dias-' + other, dias);
    descAutoPct  = pct;
    descAutoDias = dias;
    calcularTotales();
}

// ─── Notas sync ─────────────────────────────────────────
function syncNotas(from) {
    const other = from === 'desk' ? 'mob' : 'desk';
    ['notas-cliente','notas-internas'].forEach(key => {
        const src = document.getElementById(key + '-' + from);
        const dst = document.getElementById(key + '-' + other);
        if (src && dst) dst.value = src.value;
    });
}

// ─── Guardar cotización ─────────────────────────────────
async function guardarCotizacion(preview) {
    const titulo = document.getElementById('cot-titulo').value.trim();
    if (!titulo) {
        document.getElementById('cot-titulo').focus();
        alert('El título del proyecto es requerido');
        return;
    }

    const items = [];
    document.querySelectorAll('#items-list .item-card').forEach((card, i) => {
        items.push({
            orden:        i + 1,
            articulo_id:  card.dataset.articuloId || null,
            titulo:       card.querySelector('[data-campo=titulo]')?.value       || '',
            sku:          card.querySelector('[data-campo=sku]')?.value           || '',
            descripcion:  card.querySelector('[data-campo=descripcion]')?.value  || '',
            cantidad:     parseFloat(card.querySelector('[data-campo=cantidad]')?.value) || 1,
            precio_unit:  parseFloat(card.querySelector('[data-campo=precio]')?.value)  || 0,
        });
    });

    const payload = {
        titulo,
        cliente_id:            clienteSeleccionado?.id || null,
        fecha:                 document.getElementById('cot-fecha').value,
        valida_hasta:           document.getElementById('cot-vence').value,
        cupon_id:              cuponSeleccionado?.id   || null,
        descuento_auto_activo: descAutoActivo ? 1 : 0,
        descuento_auto_pct:    descAutoPct,
        descuento_auto_dias:   descAutoDias,
        notas_cliente:         document.getElementById('notas-cliente-desk')?.value  || '',
        notas_internas:        document.getElementById('notas-internas-desk')?.value || '',
        items,
        preview,
    };

    const btn = document.getElementById('btn-guardar');
    if (btn) { btn.disabled = true; btn.textContent = 'Guardando...'; }

    try {
        const r = await fetch('/cotizaciones/nueva', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN },
            body: JSON.stringify(payload)
        });
        const data = await r.json();
        if (!data.ok) {
            alert(data.error || 'Error al guardar');
            if (btn) { btn.disabled = false; btn.textContent = 'Guardar borrador'; }
            return;
        }
        window.location.href = '/cotizaciones/' + data.data.id;
    } catch (e) {
        alert('Error de conexión');
        if (btn) { btn.disabled = false; btn.textContent = 'Guardar borrador'; }
    }
}

function actualizarEstado() { /* hook futuro */ }

// ─── Helpers ────────────────────────────────────────────
function fmt(n) {
    const sym = EMPRESA_CFG.moneda === 'USD' ? 'USD ' : '$';
    return sym + parseFloat(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function strip(html) {
    const d = document.createElement('div'); d.innerHTML = html; return d.textContent || '';
}
function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }
function setVal(id, val)  { const el = document.getElementById(id); if (el) el.value = val; }
function autoResize(el)   { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; }
function toggleMob(hdr)   { hdr.closest('.mob-section').classList.toggle('open'); }
</script>
</body>
</html>
