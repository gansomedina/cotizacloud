<?php
// ============================================================
//  CotizaApp — modules/dashboard/index.php
//  GET / y GET /dashboard
// ============================================================

defined('COTIZAAPP') or die;

$empresa_id = EMPRESA_ID;
$empresa    = Auth::empresa();
$usuario    = Auth::usuario();
$moneda     = $empresa['moneda'] ?? 'MXN';

// ─── Período seleccionado ────────────────────────────────
$periodo = $_GET['periodo'] ?? 'mes_actual';
$periodos_validos = ['mes_actual','mes_ant','30_dias','90_dias','anio'];
if (!in_array($periodo, $periodos_validos)) $periodo = 'mes_actual';

$ahora   = new DateTimeImmutable('now', new DateTimeZone('America/Hermosillo'));
$mes_lbl = '';

switch ($periodo) {
    case 'mes_actual':
        $desde   = $ahora->format('Y-m-01 00:00:00');
        $hasta   = $ahora->format('Y-m-t 23:59:59');
        $mes_lbl = $ahora->format('F Y');
        break;
    case 'mes_ant':
        $ant     = $ahora->modify('first day of last month');
        $desde   = $ant->format('Y-m-01 00:00:00');
        $hasta   = $ant->format('Y-m-t 23:59:59');
        $mes_lbl = $ant->format('F Y');
        break;
    case '30_dias':
        $desde   = $ahora->modify('-30 days')->format('Y-m-d 00:00:00');
        $hasta   = $ahora->format('Y-m-d 23:59:59');
        $mes_lbl = 'Últimos 30 días';
        break;
    case '90_dias':
        $desde   = $ahora->modify('-90 days')->format('Y-m-d 00:00:00');
        $hasta   = $ahora->format('Y-m-d 23:59:59');
        $mes_lbl = 'Últimos 90 días';
        break;
    case 'anio':
        $desde   = $ahora->format('Y-01-01 00:00:00');
        $hasta   = $ahora->format('Y-12-31 23:59:59');
        $mes_lbl = 'Este año ' . $ahora->format('Y');
        break;
}

// Período anterior equivalente para comparativo
$dur_dias = (int)round((strtotime($hasta) - strtotime($desde)) / 86400) + 1;
$desde_ant = date('Y-m-d H:i:s', strtotime($desde) - $dur_dias * 86400);
$hasta_ant = date('Y-m-d H:i:s', strtotime($desde) - 1);

// ─── Filtro de asesor (si no admin, solo ve las suyas) ───
$solo_mias = !Auth::es_admin() && !Auth::puede('ver_todas_ventas');
$user_id   = Auth::id();
$v_where   = $solo_mias ? "AND v.usuario_id = $user_id" : '';
$c_where   = $solo_mias ? "AND c.usuario_id = $user_id" : '';

// ═══════════════════════════════════════════════════════
//  BLOQUE 1: KPIs FINANCIEROS
// ═══════════════════════════════════════════════════════

// Ventas del período
$kpi_ventas = DB::row(
    "SELECT
        COUNT(*) AS num_ventas,
        COALESCE(SUM(total), 0) AS monto_ventas,
        COALESCE(SUM(pagado), 0) AS monto_cobrado,
        COALESCE(SUM(saldo), 0)  AS monto_saldo
     FROM ventas v
     WHERE v.empresa_id = ? AND v.estado != 'cancelada'
       AND v.created_at BETWEEN ? AND ? $v_where",
    [$empresa_id, $desde, $hasta]
);

// Comparativo período anterior
$kpi_ventas_ant = DB::row(
    "SELECT COALESCE(SUM(total), 0) AS monto_ventas
     FROM ventas v
     WHERE v.empresa_id = ? AND v.estado != 'cancelada'
       AND v.created_at BETWEEN ? AND ? $v_where",
    [$empresa_id, $desde_ant, $hasta_ant]
);

$delta_ventas = 0;
if ((float)$kpi_ventas_ant['monto_ventas'] > 0) {
    $delta_ventas = round(
        (((float)$kpi_ventas['monto_ventas'] - (float)$kpi_ventas_ant['monto_ventas'])
        / (float)$kpi_ventas_ant['monto_ventas']) * 100
    );
}

// Cotizaciones del período
$kpi_cots = DB::row(
    "SELECT
        COUNT(*) AS num_cots,
        COALESCE(SUM(total), 0) AS monto_cots,
        SUM(estado IN ('enviada','vista','aceptada','convertida')) AS num_enviadas
     FROM cotizaciones c
     WHERE c.empresa_id = ? AND c.created_at BETWEEN ? AND ? $c_where",
    [$empresa_id, $desde, $hasta]
);

$kpi_cots_ant = DB::row(
    "SELECT COUNT(*) AS num_cots
     FROM cotizaciones c
     WHERE c.empresa_id = ? AND c.created_at BETWEEN ? AND ? $c_where",
    [$empresa_id, $desde_ant, $hasta_ant]
);
$delta_cots = (int)$kpi_cots['num_cots'] - (int)$kpi_cots_ant['num_cots'];

$num_ventas_pagadas = (int)DB::val(
    "SELECT COUNT(*) FROM ventas v WHERE v.empresa_id=? AND v.estado='pagada'
     AND v.created_at BETWEEN ? AND ? $v_where",
    [$empresa_id, $desde, $hasta]
);
$num_ventas_saldo = (int)$kpi_ventas['num_ventas'] - $num_ventas_pagadas;

// ═══════════════════════════════════════════════════════
//  BLOQUE 2: EMBUDO DE CONVERSIÓN
// ═══════════════════════════════════════════════════════

$funnel = DB::row(
    "SELECT
        COUNT(*) AS total,
        SUM(estado NOT IN ('borrador')) AS enviadas,
        SUM(estado IN ('vista','aceptada','rechazada','vencida','convertida')) AS vistas,
        SUM(estado IN ('aceptada','convertida')) AS cerradas,
        SUM(estado = 'rechazada') AS rechazadas
     FROM cotizaciones c
     WHERE c.empresa_id = ? AND c.created_at BETWEEN ? AND ? $c_where",
    [$empresa_id, $desde, $hasta]
);

$tasa_cierre = $funnel['total'] > 0
    ? round(($funnel['cerradas'] / $funnel['total']) * 100, 1)
    : 0;

$ticket_prom = $kpi_ventas['num_ventas'] > 0
    ? round($kpi_ventas['monto_ventas'] / $kpi_ventas['num_ventas'])
    : 0;

// Tiempo promedio de cierre (días entre created y aceptada_at)
$tiempo_cierre = (float)(DB::val(
    "SELECT AVG(DATEDIFF(aceptada_at, created_at))
     FROM cotizaciones c
     WHERE c.empresa_id=? AND estado IN ('aceptada','convertida')
       AND aceptada_at IS NOT NULL AND c.created_at BETWEEN ? AND ? $c_where",
    [$empresa_id, $desde, $hasta]
) ?? 0);

// Sin abrir (enviadas pero nunca vistas)
$sin_abrir = (int)DB::val(
    "SELECT COUNT(*) FROM cotizaciones c
     WHERE c.empresa_id=? AND estado='enviada'
       AND vista_at IS NULL AND c.created_at BETWEEN ? AND ? $c_where",
    [$empresa_id, $desde, $hasta]
);

// Ventas con descuento
$ventas_con_desc = (int)DB::val(
    "SELECT COUNT(*) FROM ventas v WHERE v.empresa_id=? AND v.estado != 'cancelada'
     AND (descuento_auto_amt > 0 OR cupon_monto > 0)
     AND v.created_at BETWEEN ? AND ? $v_where",
    [$empresa_id, $desde, $hasta]
);
$total_descuentos = (float)(DB::val(
    "SELECT COALESCE(SUM(COALESCE(descuento_auto_amt,0) + COALESCE(cupon_monto,0)), 0)
     FROM ventas v WHERE v.empresa_id=? AND v.estado != 'cancelada'
     AND v.created_at BETWEEN ? AND ? $v_where",
    [$empresa_id, $desde, $hasta]
) ?? 0);

// ═══════════════════════════════════════════════════════
//  BLOQUE 3: ALERTAS
// ═══════════════════════════════════════════════════════

// Aceptadas recientemente (últimos 14 días)
$aceptadas = DB::query(
    "SELECT c.id, c.titulo, c.numero AS cot_numero, c.aceptada_at,
            v.numero AS vta_numero, v.total, v.id AS venta_id,
            cl.nombre AS cliente_nombre
     FROM cotizaciones c
     LEFT JOIN ventas  v  ON v.cotizacion_id = c.id
     LEFT JOIN clientes cl ON cl.id = c.cliente_id
     WHERE c.empresa_id=? AND c.estado IN ('aceptada','convertida')
       AND c.aceptada_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) $c_where
     ORDER BY c.aceptada_at DESC LIMIT 6",
    [$empresa_id]
);

// Rechazadas recientemente (últimos 14 días)
$rechazadas = DB::query(
    "SELECT c.id, c.titulo, c.numero, c.rechazada_at, c.total, c.rechazada_motivo,
            cl.nombre AS cliente_nombre
     FROM cotizaciones c
     LEFT JOIN clientes cl ON cl.id = c.cliente_id
     WHERE c.empresa_id=? AND c.estado='rechazada'
       AND c.rechazada_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) $c_where
     ORDER BY c.rechazada_at DESC LIMIT 6",
    [$empresa_id]
);

// Próximas a vencer (enviadas/vistas, vence en ≤7 días)
$por_vencer = DB::query(
    "SELECT c.id, c.titulo, c.numero, c.valida_hasta, c.total,
            cl.nombre AS cliente_nombre,
            DATEDIFF(c.valida_hasta, CURDATE()) AS dias_restantes
     FROM cotizaciones c
     LEFT JOIN clientes cl ON cl.id = c.cliente_id
     WHERE c.empresa_id=? AND c.estado IN ('enviada','vista')
       AND c.valida_hasta IS NOT NULL
       AND c.valida_hasta BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) $c_where
     ORDER BY c.valida_hasta ASC LIMIT 6",
    [$empresa_id]
);

// Sin abrir (enviadas, estado 'enviada', sin vista_at)
$sin_abrir_list = DB::query(
    "SELECT c.id, c.titulo, c.numero, c.enviada_at, c.total,
            cl.nombre AS cliente_nombre,
            DATEDIFF(CURDATE(), DATE(c.enviada_at)) AS dias_sin_abrir
     FROM cotizaciones c
     LEFT JOIN clientes cl ON cl.id = c.cliente_id
     WHERE c.empresa_id=? AND c.estado='enviada'
       AND c.vista_at IS NULL AND c.enviada_at IS NOT NULL $c_where
     ORDER BY c.enviada_at ASC LIMIT 6",
    [$empresa_id]
);

// ═══════════════════════════════════════════════════════
//  BLOQUE 4: RADAR BUCKETS
// ═══════════════════════════════════════════════════════

// Cotizaciones activas con su bucket radar
$radar_buckets_raw = DB::query(
    "SELECT c.id, c.titulo, c.numero, c.total,
            c.radar_bucket, c.radar_score, c.visitas, c.ultima_vista_at,
            cl.nombre AS cliente_nombre,
            qs.sesiones, qs.scroll_max
     FROM cotizaciones c
     LEFT JOIN clientes cl ON cl.id = c.cliente_id
     LEFT JOIN (
         SELECT cotizacion_id,
                COUNT(*) AS sesiones,
                MAX(scroll_max) AS scroll_max
         FROM quote_sessions
         GROUP BY cotizacion_id
     ) qs ON qs.cotizacion_id = c.id
     WHERE c.empresa_id=? AND c.estado IN ('enviada','vista') $c_where
       AND c.radar_bucket IS NOT NULL
     ORDER BY c.radar_score DESC LIMIT 20",
    [$empresa_id]
);

// Agrupar por bucket
$buckets = ['onfire' => [], 'inminente' => [], 'probable' => []];
foreach ($radar_buckets_raw as $r) {
    $b = $r['radar_bucket'];
    if (isset($buckets[$b])) $buckets[$b][] = $r;
}

// ═══════════════════════════════════════════════════════
//  BLOQUE 5: ACTIVIDAD DEL MES
// ═══════════════════════════════════════════════════════

$act_cots = DB::row(
    "SELECT
        COUNT(*) AS total,
        COALESCE(SUM(total), 0) AS monto_total,
        SUM(estado IN ('aceptada','convertida')) AS cerradas,
        SUM(estado = 'rechazada') AS rechazadas,
        SUM(estado IN ('enviada','vista')) AS pendientes
     FROM cotizaciones c
     WHERE c.empresa_id=? AND c.created_at BETWEEN ? AND ? $c_where",
    [$empresa_id, $desde, $hasta]
);

$act_ventas = DB::row(
    "SELECT
        COUNT(*) AS total,
        COALESCE(SUM(total), 0) AS monto_total,
        SUM(estado = 'pagada' OR estado = 'entregada') AS pagadas,
        SUM(estado IN ('parcial','pendiente')) AS con_saldo,
        COALESCE(SUM(pagado), 0) AS cobrado
     FROM ventas v
     WHERE v.empresa_id=? AND v.estado != 'cancelada'
       AND v.created_at BETWEEN ? AND ? $v_where",
    [$empresa_id, $desde, $hasta]
);

// ─── Helpers ─────────────────────────────────────────────
function fmt_dash(float $n, string $moneda = 'MXN'): string {
    if ($n >= 1_000_000) return '$' . number_format($n / 1_000_000, 1) . 'M';
    if ($n >= 1_000)     return '$' . number_format($n / 1_000, 0) . 'K';
    return '$' . number_format($n, 0);
}
function fmt_full(float $n): string {
    return '$' . number_format($n, 0, '.', ',');
}
function iniciales_d(string $nombre): string {
    $p = array_filter(explode(' ', $nombre));
    $i = '';
    foreach (array_slice($p, 0, 2) as $w) $i .= strtoupper($w[0]);
    return $i ?: '?';
}
function dias_lbl(int $dias, bool $pasado = false): array {
    if ($pasado) {
        if ($dias === 0)  return ['Hoy',        'dias-green'];
        if ($dias === 1)  return ['Hace 1 día',  'dias-green'];
        if ($dias <= 7)   return ["Hace $dias días", 'dias-green'];
        return ["Hace $dias días", 'dias-amb'];
    } else {
        if ($dias < 0)    return ['Venció hace ' . abs($dias) . ' d.', 'dias-red'];
        if ($dias === 0)  return ['Vence hoy',    'dias-red'];
        if ($dias <= 2)   return ["Vence en $dias días", 'dias-red'];
        if ($dias <= 5)   return ["Vence en $dias días", 'dias-amb'];
        return ["Vence en $dias días", 'dias-green'];
    }
}

$mes_lbl_cap = ucfirst($mes_lbl);

$page_title = 'Inicio';
ob_start();
?>
<style>
/* KPI GRID */
.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.kpi-card{background:var(--white);border:1px solid var(--border);border-radius:var(--r);padding:16px;box-shadow:var(--sh);position:relative;overflow:hidden}
.kpi-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px}
.kpi-ventas::before{background:var(--g)}
.kpi-cobrado::before{background:#059669}
.kpi-pendiente::before{background:#f59e0b}
.kpi-cots::before{background:var(--blue)}
.kpi-label{font:700 10px var(--body);letter-spacing:.07em;text-transform:uppercase;color:var(--t3);margin-bottom:6px}
.kpi-val{font:300 26px var(--num);letter-spacing:-.02em;line-height:1;color:var(--text)}
.kpi-val.green{color:var(--g)}.kpi-val.amber{color:#b45309}.kpi-val.blue{color:var(--blue)}
.kpi-sub{font:400 12px var(--num);color:var(--t3);margin-top:5px}
.kpi-sub span{color:var(--g);font-weight:500}
.kpi-sub span.neg{color:var(--danger)}
.kpi-ico{position:absolute;top:14px;right:14px;font-size:18px;opacity:.22}

/* CONVERSIÓN */
.conv-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.conv-card{background:var(--white);border:1px solid var(--border);border-radius:var(--r);padding:16px;box-shadow:var(--sh)}
.conv-title{font:700 13px var(--body);margin-bottom:12px}
.conv-funnel{display:flex;flex-direction:column;gap:6px}
.funnel-row{display:flex;align-items:center;gap:10px}
.funnel-lbl{font:500 12px var(--body);color:var(--t2);width:90px;flex-shrink:0}
.funnel-bar-wrap{flex:1;height:20px;background:var(--bg);border-radius:4px;overflow:hidden}
.funnel-bar{height:100%;border-radius:4px;transition:width .6s ease}
.fb-total{background:#cbd5e1}.fb-enviadas{background:#60a5fa}.fb-vistas{background:#34d399}.fb-cerradas{background:var(--g)}
.funnel-num{font:600 12px var(--num);color:var(--text);width:26px;text-align:right;flex-shrink:0}
.funnel-pct{font:400 11px var(--num);color:var(--t3);width:36px;text-align:right;flex-shrink:0}
.conv-metrics{display:flex;flex-direction:column;gap:8px}
.conv-metric{display:flex;justify-content:space-between;align-items:center;padding:9px 12px;border-radius:var(--r-sm);background:var(--bg)}
.conv-metric-lbl{font:500 13px var(--body);color:var(--t2)}
.conv-metric-val{font:600 15px var(--num);color:var(--text)}
.conv-metric-val.g{color:var(--g)}.conv-metric-val.b{color:var(--blue)}.conv-metric-val.a{color:#b45309}

/* ALERTAS */
.alert-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.alert-card{background:var(--white);border:1px solid var(--border);border-radius:var(--r);box-shadow:var(--sh);overflow:hidden}
.alert-header{padding:11px 14px 10px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.alert-title{font:700 13px var(--body);display:flex;align-items:center;gap:7px}
.alert-badge{padding:2px 8px;border-radius:20px;font:700 11px var(--body)}
.ab-green{background:var(--g-light);color:var(--g)}.ab-red{background:var(--danger-bg);color:var(--danger)}.ab-amber{background:var(--amb-bg);color:var(--amb)}
.alert-row{display:flex;align-items:center;gap:10px;padding:9px 14px;border-bottom:1px solid var(--border);text-decoration:none;color:inherit;transition:background .1s}
.alert-row:last-child{border-bottom:none}
.alert-row:hover{background:#fafaf8}
.alert-empty{padding:20px 14px;text-align:center;font:400 13px var(--body);color:var(--t3)}
.alert-av{width:32px;height:32px;border-radius:8px;background:var(--g);display:flex;align-items:center;justify-content:center;font:700 12px var(--body);color:#fff;flex-shrink:0}
.alert-av.red{background:var(--danger)}.alert-av.amber{background:#d97706}.alert-av.slate{background:#64748b}
.alert-info{flex:1;min-width:0}
.alert-name{font:600 13px var(--body);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.alert-meta{font:400 11px var(--num);color:var(--t3);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.alert-r{text-align:right;flex-shrink:0}
.alert-monto{font:500 13px var(--num);color:var(--text)}
.alert-dias{font:700 11px var(--body);margin-top:2px}
.dias-red{color:var(--danger)}.dias-amb{color:#b45309}.dias-green{color:var(--g)}

/* RADAR BUCKETS */
.buckets-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.bucket-card{background:var(--white);border:1px solid var(--border);border-radius:var(--r);overflow:hidden;box-shadow:var(--sh)}
.bucket-header{padding:12px 14px 10px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.bucket-title{font:700 13px var(--body);display:flex;align-items:center;gap:7px}
.b-probable .bucket-header{background:#fffbeb}.b-inminente .bucket-header{background:#fff7ed}.b-onfire .bucket-header{background:#fff1f2}
.bucket-total{font:600 12px var(--num);color:var(--t3)}
.bucket-row{display:flex;align-items:center;gap:8px;padding:9px 14px;border-bottom:1px solid var(--border);text-decoration:none;color:inherit;transition:background .1s}
.bucket-row:last-child{border-bottom:none}
.bucket-row:hover{background:#fafaf8}
.bucket-av{width:28px;height:28px;border-radius:7px;background:var(--g);display:flex;align-items:center;justify-content:center;font:700 11px var(--body);color:#fff;flex-shrink:0}
.bucket-info{flex:1;min-width:0}
.bucket-client{font:600 12px var(--body);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bucket-proyecto{font:400 11px var(--body);color:var(--t3);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bucket-r{text-align:right;flex-shrink:0}
.bucket-monto{font:500 12px var(--num)}
.heat{display:flex;gap:2px;margin-top:3px;justify-content:flex-end}
.heat-dot{width:6px;height:6px;border-radius:50%}
.hd-off{background:var(--border)}.hd-low{background:#fbbf24}.hd-mid{background:#f97316}.hd-hot{background:#ef4444}
.bucket-empty{padding:20px 14px;text-align:center;font:400 13px var(--body);color:var(--t3)}

/* ACTIVIDAD MENSUAL */
.monthly-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.monthly-card{background:var(--white);border:1px solid var(--border);border-radius:var(--r);padding:16px;box-shadow:var(--sh)}
.monthly-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.monthly-title{font:700 13px var(--body)}
.monthly-big{font:300 32px var(--num);letter-spacing:-.03em;line-height:1;margin-bottom:4px}
.monthly-big.g{color:var(--g)}
.monthly-sub{font:400 12px var(--num);color:var(--t3)}
.monthly-divider{height:1px;background:var(--border);margin:12px 0}
.monthly-row{display:flex;justify-content:space-between;align-items:center;padding:5px 0}
.monthly-row-lbl{font:500 12px var(--body);color:var(--t2)}
.monthly-row-val{font:500 13px var(--num);color:var(--text)}

/* SECTION LABEL */
.slabel{font:700 11px var(--body);letter-spacing:.07em;text-transform:uppercase;color:var(--t2);margin:24px 0 10px;display:flex;align-items:center;gap:10px}
.slabel::after{content:'';flex:1;height:1.5px;background:var(--border)}
.slabel:first-child{margin-top:0}

/* RESPONSIVE */
@media(max-width:900px){
  .kpi-grid{grid-template-columns:repeat(2,1fr)}
  .conv-grid,.monthly-grid{grid-template-columns:1fr}
  .alert-grid{grid-template-columns:1fr}
  .buckets-grid{grid-template-columns:1fr}
}
@media(max-width:600px){
  .kpi-grid{grid-template-columns:1fr 1fr}
  .kpi-val{font-size:20px}
}
</style>

<!-- SELECTOR DE PERÍODO (en topbar via slot extra) -->
<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; flex-wrap:wrap; gap:10px;">
  <div>
    <h1 style="font:800 22px var(--body); letter-spacing:-.02em;">Inicio</h1>
    <p style="font:400 13px var(--body); color:var(--t3); margin-top:2px;"><?= e($mes_lbl_cap) ?></p>
  </div>
  <form method="get" style="display:flex; align-items:center; gap:6px;">
    <select name="periodo" onchange="this.form.submit()"
            style="padding:8px 12px; border-radius:var(--r-sm); border:1.5px solid var(--border); font:600 13px var(--body); color:var(--t2); background:var(--white); box-shadow:var(--sh); cursor:pointer;">
      <option value="mes_actual"  <?= $periodo==='mes_actual' ?'selected':''?>>Este mes</option>
      <option value="mes_ant"     <?= $periodo==='mes_ant'    ?'selected':''?>>Mes anterior</option>
      <option value="30_dias"     <?= $periodo==='30_dias'    ?'selected':''?>>Últimos 30 días</option>
      <option value="90_dias"     <?= $periodo==='90_dias'    ?'selected':''?>>Últimos 90 días</option>
      <option value="anio"        <?= $periodo==='anio'       ?'selected':''?>>Este año</option>
    </select>
  </form>
</div>

<!-- ══ KPIs FINANCIEROS ══ -->
<div class="slabel">Resumen financiero · <?= e($mes_lbl_cap) ?></div>
<div class="kpi-grid">

  <div class="kpi-card kpi-ventas">
    <div class="kpi-ico">💰</div>
    <div class="kpi-label">Ventas del período</div>
    <div class="kpi-val green"><?= fmt_dash((float)$kpi_ventas['monto_ventas']) ?></div>
    <div class="kpi-sub">
      <?= (int)$kpi_ventas['num_ventas'] ?> venta<?= $kpi_ventas['num_ventas']!=1?'s':'' ?> ·
      <?php if ($delta_ventas !== 0): ?>
      <span class="<?= $delta_ventas >= 0 ? '' : 'neg' ?>">
        <?= $delta_ventas >= 0 ? '↑' : '↓' ?> <?= abs($delta_ventas) ?>% vs anterior
      </span>
      <?php else: ?>
      <span>sin cambio</span>
      <?php endif; ?>
    </div>
  </div>

  <div class="kpi-card kpi-cobrado">
    <div class="kpi-ico">✅</div>
    <div class="kpi-label">Cobrado</div>
    <div class="kpi-val green"><?= fmt_dash((float)$kpi_ventas['monto_cobrado']) ?></div>
    <div class="kpi-sub">
      <?php
      $pct_cob = $kpi_ventas['monto_ventas'] > 0
          ? round(($kpi_ventas['monto_cobrado'] / $kpi_ventas['monto_ventas']) * 100, 1) : 0;
      ?>
      <?= $pct_cob ?>% del total ·
      <span><?= $num_ventas_pagadas ?> venta<?= $num_ventas_pagadas!=1?'s':'' ?> completa<?= $num_ventas_pagadas!=1?'s':'' ?></span>
    </div>
  </div>

  <div class="kpi-card kpi-pendiente">
    <div class="kpi-ico">⏳</div>
    <div class="kpi-label">Por cobrar</div>
    <div class="kpi-val amber"><?= fmt_dash((float)$kpi_ventas['monto_saldo']) ?></div>
    <div class="kpi-sub">
      <?= $num_ventas_saldo ?> venta<?= $num_ventas_saldo!=1?'s':'' ?> con saldo ·
      <?php $pct_pend = 100 - $pct_cob; ?>
      <span class="<?= $pct_pend > 50 ? 'neg' : '' ?>"><?= $pct_pend ?>% pendiente</span>
    </div>
  </div>

  <div class="kpi-card kpi-cots">
    <div class="kpi-ico">📋</div>
    <div class="kpi-label">Cotizaciones creadas</div>
    <div class="kpi-val blue"><?= (int)$kpi_cots['num_cots'] ?></div>
    <div class="kpi-sub">
      <?= fmt_dash((float)$kpi_cots['monto_cots']) ?> total cotizado ·
      <?php if ($delta_cots !== 0): ?>
      <span class="<?= $delta_cots < 0 ? 'neg' : '' ?>">
        <?= $delta_cots >= 0 ? '↑' : '↓' ?> <?= abs($delta_cots) ?> vs anterior
      </span>
      <?php else: ?>
      <span>igual que antes</span>
      <?php endif; ?>
    </div>
  </div>

</div>

<!-- ══ CONVERSIÓN ══ -->
<div class="slabel">Métricas de conversión</div>
<div class="conv-grid">

  <div class="conv-card">
    <div class="conv-title">Embudo del período</div>
    <div class="conv-funnel">
      <?php
      $total_f = max(1, (int)$funnel['total']);
      $rows_f  = [
          ['Creadas',  'fb-total',    $funnel['total'],   100],
          ['Enviadas', 'fb-enviadas', $funnel['enviadas'], round($funnel['enviadas']/$total_f*100)],
          ['Vistas',   'fb-vistas',   $funnel['vistas'],   round($funnel['vistas']/$total_f*100)],
          ['Cerradas', 'fb-cerradas', $funnel['cerradas'], round($funnel['cerradas']/$total_f*100)],
      ];
      foreach ($rows_f as [$lbl, $cls, $num, $pct]):
      ?>
      <div class="funnel-row">
        <div class="funnel-lbl"><?= $lbl ?></div>
        <div class="funnel-bar-wrap">
          <div class="funnel-bar <?= $cls ?>" style="width:<?= $pct ?>%"></div>
        </div>
        <div class="funnel-num"><?= (int)$num ?></div>
        <div class="funnel-pct"><?= $pct ?>%</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="conv-card">
    <div class="conv-title">Indicadores clave</div>
    <div class="conv-metrics">
      <div class="conv-metric">
        <span class="conv-metric-lbl">Tasa de cierre</span>
        <span class="conv-metric-val g"><?= $tasa_cierre ?>%</span>
      </div>
      <div class="conv-metric">
        <span class="conv-metric-lbl">Ticket promedio</span>
        <span class="conv-metric-val"><?= $ticket_prom > 0 ? fmt_full($ticket_prom) : '—' ?></span>
      </div>
      <div class="conv-metric">
        <span class="conv-metric-lbl">Tiempo promedio de cierre</span>
        <span class="conv-metric-val b"><?= $tiempo_cierre > 0 ? number_format($tiempo_cierre, 1) . ' días' : '—' ?></span>
      </div>
      <div class="conv-metric">
        <span class="conv-metric-lbl">Cotizaciones rechazadas</span>
        <span class="conv-metric-val a"><?= (int)$funnel['rechazadas'] ?></span>
      </div>
      <div class="conv-metric">
        <span class="conv-metric-lbl">Cotizaciones sin abrir</span>
        <span class="conv-metric-val a"><?= $sin_abrir ?></span>
      </div>
      <?php if ($kpi_ventas['num_ventas'] > 0): ?>
      <div class="conv-metric" style="flex-direction:column; align-items:flex-start; gap:3px;">
        <div style="display:flex; justify-content:space-between; width:100%;">
          <span class="conv-metric-lbl">Ventas con descuento</span>
          <span class="conv-metric-val a"><?= $ventas_con_desc ?> de <?= (int)$kpi_ventas['num_ventas'] ?></span>
        </div>
        <?php if ($total_descuentos > 0): ?>
        <div style="font:400 12px var(--num); color:var(--t3);"><?= fmt_full($total_descuentos) ?> en descuentos aplicados</div>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

</div>

<!-- ══ ALERTAS ══ -->
<div class="slabel">Alertas</div>
<div class="alert-grid">

  <!-- Aceptadas recientemente -->
  <div class="alert-card">
    <div class="alert-header">
      <div class="alert-title">✅ Aceptadas recientemente <span class="alert-badge ab-green"><?= count($aceptadas) ?></span></div>
    </div>
    <?php if (empty($aceptadas)): ?>
    <div class="alert-empty">Sin cotizaciones aceptadas recientemente.</div>
    <?php else: ?>
    <?php foreach ($aceptadas as $a):
      $ini = iniciales_d($a['cliente_nombre'] ?? '?');
      $dias = max(0, (int)floor((time() - strtotime($a['aceptada_at'])) / 86400));
      [$dlbl, $dcls] = dias_lbl($dias, true);
      $href = $a['venta_id'] ? '/ventas/'.$a['venta_id'] : '/cotizaciones/'.$a['id'];
    ?>
    <a href="<?= $href ?>" class="alert-row">
      <div class="alert-av"><?= e($ini) ?></div>
      <div class="alert-info">
        <div class="alert-name"><?= e($a['cliente_nombre'] ?? '—') ?></div>
        <div class="alert-meta"><?= e(mb_substr($a['titulo'],0,45)) ?> · <?= e($a['vta_numero'] ?? $a['cot_numero']) ?></div>
      </div>
      <div class="alert-r">
        <div class="alert-monto"><?= fmt_dash((float)$a['total']) ?></div>
        <div class="alert-dias <?= $dcls ?>"><?= $dlbl ?></div>
      </div>
    </a>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Rechazadas -->
  <div class="alert-card">
    <div class="alert-header">
      <div class="alert-title">✕ Rechazadas <span class="alert-badge ab-red"><?= count($rechazadas) ?></span></div>
    </div>
    <?php if (empty($rechazadas)): ?>
    <div class="alert-empty">Sin rechazos recientes.</div>
    <?php else: ?>
    <?php foreach ($rechazadas as $r):
      $ini = iniciales_d($r['cliente_nombre'] ?? '?');
      $dias = max(0, (int)floor((time() - strtotime($r['rechazada_at'])) / 86400));
      [$dlbl, $dcls] = dias_lbl($dias, true);
      $dcls = $dias <= 2 ? 'dias-red' : 'dias-amb';
    ?>
    <a href="/cotizaciones/<?= (int)$r['id'] ?>" class="alert-row">
      <div class="alert-av red"><?= e($ini) ?></div>
      <div class="alert-info">
        <div class="alert-name"><?= e($r['cliente_nombre'] ?? '—') ?></div>
        <div class="alert-meta"><?= e(mb_substr($r['titulo'],0,45)) ?> · <?= e($r['numero']) ?></div>
      </div>
      <div class="alert-r">
        <div class="alert-monto"><?= fmt_dash((float)$r['total']) ?></div>
        <div class="alert-dias <?= $dcls ?>"><?= $dlbl ?></div>
      </div>
    </a>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Próximas a vencer -->
  <div class="alert-card">
    <div class="alert-header">
      <div class="alert-title">⏰ Próximas a vencer <span class="alert-badge ab-amber"><?= count($por_vencer) ?></span></div>
    </div>
    <?php if (empty($por_vencer)): ?>
    <div class="alert-empty">Sin cotizaciones próximas a vencer.</div>
    <?php else: ?>
    <?php foreach ($por_vencer as $pv):
      $ini = iniciales_d($pv['cliente_nombre'] ?? '?');
      $dias = (int)$pv['dias_restantes'];
      [$dlbl, $dcls] = dias_lbl($dias, false);
    ?>
    <a href="/cotizaciones/<?= (int)$pv['id'] ?>" class="alert-row">
      <div class="alert-av amber"><?= e($ini) ?></div>
      <div class="alert-info">
        <div class="alert-name"><?= e($pv['cliente_nombre'] ?? '—') ?></div>
        <div class="alert-meta"><?= e(mb_substr($pv['titulo'],0,45)) ?> · <?= e($pv['numero']) ?></div>
      </div>
      <div class="alert-r">
        <div class="alert-monto"><?= fmt_dash((float)$pv['total']) ?></div>
        <div class="alert-dias <?= $dcls ?>"><?= $dlbl ?></div>
      </div>
    </a>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Sin abrir -->
  <div class="alert-card">
    <div class="alert-header">
      <div class="alert-title">📭 Sin abrir <span class="alert-badge ab-amber"><?= count($sin_abrir_list) ?></span></div>
    </div>
    <?php if (empty($sin_abrir_list)): ?>
    <div class="alert-empty">Todas las cotizaciones enviadas han sido abiertas.</div>
    <?php else: ?>
    <?php foreach ($sin_abrir_list as $sa):
      $ini  = iniciales_d($sa['cliente_nombre'] ?? '?');
      $dias = max(0, (int)$sa['dias_sin_abrir']);
      $dcls = $dias >= 5 ? 'dias-red' : ($dias >= 3 ? 'dias-amb' : 'dias-amb');
    ?>
    <a href="/cotizaciones/<?= (int)$sa['id'] ?>" class="alert-row">
      <div class="alert-av <?= $dias >= 5 ? 'slate' : 'amber' ?>"><?= e($ini) ?></div>
      <div class="alert-info">
        <div class="alert-name"><?= e($sa['cliente_nombre'] ?? '—') ?></div>
        <div class="alert-meta">Enviada hace <?= $dias ?> día<?= $dias!=1?'s':'' ?> · <?= e($sa['numero']) ?></div>
      </div>
      <div class="alert-r">
        <div class="alert-monto"><?= fmt_dash((float)$sa['total']) ?></div>
        <div class="alert-dias <?= $dcls ?>"><?= $dias ?> día<?= $dias!=1?'s':'' ?> sin abrir</div>
      </div>
    </a>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

</div>

<!-- ══ RADAR BUCKETS ══ -->
<?php
$hay_radar = !empty($buckets['onfire']) || !empty($buckets['inminente']) || !empty($buckets['probable']);
?>
<div class="slabel">Radar · oportunidades activas</div>
<div class="buckets-grid">

  <?php
  $bucket_def = [
      'probable'  => ['🟡', 'Probable cierre',    'b-probable'],
      'inminente' => ['🟠', 'Cierre inminente',   'b-inminente'],
      'onfire'    => ['🔴', 'On Fire',             'b-onfire'],
  ];
  foreach ($bucket_def as $bkey => [$ico, $blbl, $bcls]):
      $items     = $buckets[$bkey];
      $total_b   = array_sum(array_column($items, 'total'));
      $count_b   = count($items);

      // Colores de avatar según bucket
      $av_colors = ['probable'=>'var(--g)', 'inminente'=>'#c2410c', 'onfire'=>'#991b1b'];
      $av_bg     = $av_colors[$bkey];
  ?>
  <div class="bucket-card <?= $bcls ?>">
    <div class="bucket-header">
      <div class="bucket-title"><span class="bucket-icon"><?= $ico ?></span> <?= $blbl ?></div>
      <div class="bucket-total">
        <?= $count_b > 0 ? fmt_dash($total_b) . ' · ' . $count_b . ' cot' . ($count_b!=1?'s.':'.') : '—' ?>
      </div>
    </div>
    <?php if (empty($items)): ?>
    <div class="bucket-empty">Sin cotizaciones en este bucket.</div>
    <?php else: ?>
    <?php foreach ($items as $item):
      $ini_b = iniciales_d($item['cliente_nombre'] ?? '?');
      // Heat dots basados en score o visitas
      $score = (float)($item['radar_score'] ?? 0);
      $dots  = [];
      $dot_count = 5;
      $hot_count = min(5, max(0, (int)round($score / 20)));
      for ($d = 0; $d < $dot_count; $d++) {
          if ($d < $hot_count) {
              $dots[] = $score >= 80 ? 'hd-hot' : ($score >= 60 ? 'hd-hot' : ($score >= 40 ? 'hd-mid' : 'hd-low'));
          } else {
              $dots[] = 'hd-off';
          }
      }
    ?>
    <a href="/cotizaciones/<?= (int)$item['id'] ?>" class="bucket-row">
      <div class="bucket-av" style="background:<?= $av_bg ?>"><?= e($ini_b) ?></div>
      <div class="bucket-info">
        <div class="bucket-client"><?= e($item['cliente_nombre'] ?? '—') ?></div>
        <div class="bucket-proyecto"><?= e(mb_substr($item['titulo'],0,40)) ?></div>
      </div>
      <div class="bucket-r">
        <div class="bucket-monto"><?= fmt_dash((float)$item['total']) ?></div>
        <div class="heat">
          <?php foreach ($dots as $dc): ?><div class="heat-dot <?= $dc ?>"></div><?php endforeach; ?>
        </div>
      </div>
    </a>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>

</div>

<?php if (!$hay_radar): ?>
<div style="background:var(--white); border:1px solid var(--border); border-radius:var(--r); padding:20px; text-align:center; margin-top:-4px;">
  <div style="font:600 14px var(--body); color:var(--t2); margin-bottom:4px;">El Radar no tiene datos aún</div>
  <div style="font:400 13px var(--body); color:var(--t3);">Los buckets se llenan automáticamente cuando se envían cotizaciones y los clientes las visitan.</div>
</div>
<?php endif; ?>

<!-- ══ ACTIVIDAD DEL MES ══ -->
<div class="slabel">Actividad del período</div>
<div class="monthly-grid">

  <div class="monthly-card">
    <div class="monthly-header">
      <div class="monthly-title">📋 Cotizaciones</div>
    </div>
    <div class="monthly-big"><?= (int)$act_cots['total'] ?></div>
    <div class="monthly-sub">cotizaciones generadas</div>
    <div class="monthly-divider"></div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Total cotizado</span>
      <span class="monthly-row-val"><?= fmt_full((float)$act_cots['monto_total']) ?></span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Ticket promedio</span>
      <span class="monthly-row-val">
        <?= $act_cots['total'] > 0 ? fmt_full($act_cots['monto_total'] / $act_cots['total']) : '—' ?>
      </span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Cerradas / convertidas</span>
      <span class="monthly-row-val">
        <?= (int)$act_cots['cerradas'] ?>
        <?= $act_cots['total'] > 0 ? '(' . round($act_cots['cerradas']/$act_cots['total']*100, 1) . '%)' : '' ?>
      </span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Rechazadas</span>
      <span class="monthly-row-val"><?= (int)$act_cots['rechazadas'] ?></span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Pendientes de respuesta</span>
      <span class="monthly-row-val"><?= (int)$act_cots['pendientes'] ?></span>
    </div>
  </div>

  <div class="monthly-card">
    <div class="monthly-header">
      <div class="monthly-title">💰 Ventas</div>
    </div>
    <div class="monthly-big g"><?= (int)$act_ventas['total'] ?></div>
    <div class="monthly-sub">ventas generadas</div>
    <div class="monthly-divider"></div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Total en ventas</span>
      <span class="monthly-row-val"><?= fmt_full((float)$act_ventas['monto_total']) ?></span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Ticket promedio</span>
      <span class="monthly-row-val">
        <?= $act_ventas['total'] > 0 ? fmt_full($act_ventas['monto_total'] / $act_ventas['total']) : '—' ?>
      </span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Completamente pagadas</span>
      <span class="monthly-row-val"><?= (int)$act_ventas['pagadas'] ?></span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Con saldo pendiente</span>
      <span class="monthly-row-val"><?= (int)$act_ventas['con_saldo'] ?></span>
    </div>
    <div class="monthly-row">
      <span class="monthly-row-lbl">Total cobrado</span>
      <span class="monthly-row-val"><?= fmt_full((float)$act_ventas['cobrado']) ?></span>
    </div>
  </div>

</div>


<?php
$content = ob_get_clean();
require ROOT_PATH . '/core/layout.php';
